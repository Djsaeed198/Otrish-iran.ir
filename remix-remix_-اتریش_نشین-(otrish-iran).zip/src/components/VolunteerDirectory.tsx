import React from 'react';
import SEO from './SEO';

const VolunteerDirectory: React.FC = () => {
    return (
        <div className="p-6">
            <SEO title="فرصت‌های داوطلبانه و خیریه" description="پلتفرم معرفی فرصت‌های عام‌المنفعه و کمک به جامعه ایرانیان" />
            <h2 className="text-2xl font-black text-stone-900 mb-6">جامعه نیکوکاری و داوطلبان</h2>
            <div className="bg-stone-100 p-4 rounded-xl text-stone-600 text-sm">
                نمایش لیست فرصت‌های داوطلبانه و خیریه‌ها.
            </div>
        </div>
    );
};
export default VolunteerDirectory;
