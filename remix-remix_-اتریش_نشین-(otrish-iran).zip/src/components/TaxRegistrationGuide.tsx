import React from 'react';
import SEO from './SEO';

const TaxRegistrationGuide: React.FC = () => {
    return (
        <div className="p-6">
            <SEO title="راهنمای ثبت‌نام مالیاتی (Steuernummer)" description="مراحل دریافت کد مالیاتی و ثبت‌نام فریلنسری در اداره مالیات اتریش" />
            <h2 className="text-2xl font-black text-stone-900 mb-6">راهنمای ثبت‌نام مالیاتی</h2>
            <div className="bg-stone-100 p-4 rounded-xl text-stone-600 text-sm">
                مراحل دریافت کد مالیاتی برای فریلنسرها.
            </div>
        </div>
    );
};
export default TaxRegistrationGuide;
