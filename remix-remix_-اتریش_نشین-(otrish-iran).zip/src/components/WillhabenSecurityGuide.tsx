import React from 'react';
import SEO from './SEO';

const WillhabenSecurityGuide: React.FC = () => {
    return (
        <div className="p-6">
            <SEO title="راهنمای امن خرید از ویلهابن" description="تکنیک‌های معامله امن در پلتفرم Willhaben، پرداخت PayLivery و اصطلاحات کلیدی" />
            <h2 className="text-2xl font-black text-stone-900 mb-6">راهنمای خرید امن از Willhaben</h2>
            <div className="bg-stone-100 p-4 rounded-xl text-stone-600 text-sm">
                نکات ایمنی خرید و فروش در Willhaben در اینجا قرار می‌گیرد.
            </div>
        </div>
    );
};
export default WillhabenSecurityGuide;
