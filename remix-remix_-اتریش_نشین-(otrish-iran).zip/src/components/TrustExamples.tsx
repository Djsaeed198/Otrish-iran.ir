import React, { useState } from "react";
import { GraduationCap, Search, Briefcase, Landmark, IdCard, Rocket, School, LucideIcon, X } from "lucide-react";

interface VisaConfig {
  id: number;
  title: string;
  segment: string;
}

interface VisaCardData {
  id: string;
  visaId: number;
  title: string;
  segment: string;
  lastExtended: string;
  workStatus: string;
  issuer: string;
  imageUrl?: string;
}

interface TrustExamplesProps {
  onNavigate: (segment: string) => void;
}

const visaItems: VisaConfig[] = [
  { id: 1, title: "ویزای دانشجویی", segment: "schools" },
  { id: 2, title: "ویزای جستجوی کار", segment: "tracker" },
  { id: 3, title: "ویزای کاری", segment: "mapper" },
  { id: 4, title: "ویزای تمکن مالی (خودحمایتی)", segment: "tracker" },
  { id: 5, title: "کارت قرمز-سفید-قرمز", segment: "tracker" },
  { id: 6, title: "ویزای استارت‌آپ", segment: "mapper" },
  { id: 7, title: "پذیرش‌های تحصیلی", segment: "schools" },
];

const visaIcons: Record<number, LucideIcon> = {
  1: GraduationCap,
  2: Search,
  3: Briefcase,
  4: Landmark,
  5: IdCard,
  6: Rocket,
  7: School
};

const visaImages = [
  "https://otrish-iran.ir/otrish-Neshin%20app/78787878.jpg",
  "https://otrish-iran.ir/otrish-Neshin%20app/546456456456.jpg",
  "https://otrish-iran.ir/otrish-Neshin%20app/54645645645.jpg",
  "https://otrish-iran.ir/otrish-Neshin%20app/454545454.jpg",
  "https://otrish-iran.ir/otrish-Neshin%20app/Untitled-1%204545copy.jpg"
];

const allCards: VisaCardData[] = visaItems.flatMap(v =>
  Array.from({ length: 5 }, (_, i) => ({
    id: `${v.id}-${i}`,
    visaId: v.id,
    title: `${v.title} - نمونه ${i + 1}`,
    segment: v.segment,
    lastExtended: "خرداد ۱۴۰۴",
    workStatus: i % 2 === 0 ? "آزاد" : "محدود",
    issuer: (v.id === 1 || v.id === 7) ? "دانشگاه وین" : "اداره اقامت وین",
    imageUrl: visaImages[i % visaImages.length]
  }))
);

const SUPPORT_NUMBER = "436601234567";

const handleCardClick = (item: VisaCardData, onNavigate: (s: string) => void) => {
    onNavigate(item.segment);
    const message = encodeURIComponent(`سلام، من در مورد ${item.title} نیاز به مشاوره دارم.`);
    window.open(`https://wa.me/${SUPPORT_NUMBER}?text=${message}`, '_blank');
};

interface VisaCardProps { 
  item: VisaCardData;
  onViewImage: (item: VisaCardData | null) => void;
}

const VisaCard: React.FC<VisaCardProps> = ({ item, onViewImage }) => {
    const Icon = visaIcons[item.visaId] || IdCard;
    return (
        <div 
            onClick={() => onViewImage(item)}
            className="aspect-[4/5] relative overflow-hidden rounded-[2rem] border border-stone-700/80 shadow-2xl flex flex-col items-center justify-center text-stone-100 p-6 text-center transition-all duration-500 hover:border-red-500/50 hover:shadow-red-500/20 cursor-pointer group"
            role="button"
            aria-label={`مشاهده جزئیات ${item.title}`}
        >
            {/* Background Image with elegant overlay */}
            {item.imageUrl && (
                <>
                    <div 
                        className="absolute inset-0 z-0 bg-cover bg-center transition-transform duration-700 scale-100 group-hover:scale-105" 
                        style={{ backgroundImage: `url('${item.imageUrl}')` }}
                    />
                    <div className="absolute inset-0 z-10 bg-gradient-to-t from-stone-950 via-stone-950/92 to-stone-950/85 transition-all duration-500 group-hover:via-stone-950/90" />
                </>
            )}
            
            {/* Content Container */}
            <div className="relative z-20 flex flex-col items-center justify-between w-full h-full">
                <div className="flex flex-col items-center">
                    <div className="p-3 bg-red-950/30 rounded-2xl border border-red-500/20 mb-3 group-hover:border-red-500/40 transition-colors">
                        <Icon className="w-8 h-8 text-red-500 transition-transform duration-500 group-hover:scale-110" />
                    </div>
                    <span className="text-stone-400 text-[9px] font-bold uppercase tracking-widest bg-stone-900/60 px-2 py-0.5 rounded-full border border-stone-800">نمونه اخذ شده</span>
                    <h4 className="text-xs sm:text-sm font-black text-white mt-2 mb-1 drop-shadow-md">{item.title}</h4>
                </div>
                
                <div className="w-full bg-stone-900/40 backdrop-blur-sm rounded-xl p-3 border border-stone-800/50 space-y-2 text-[10px] text-stone-200">
                    <div className="flex justify-between"><span>صادرکننده:</span><span className="font-bold text-white drop-shadow-sm">{item.issuer}</span></div>
                    <div className="flex justify-between"><span>وضعیت کار:</span><span className="font-bold text-stone-200 drop-shadow-sm">{item.workStatus}</span></div>
                    <div className="flex justify-between"><span>آخرین تمدید:</span><span className="font-bold text-stone-200 drop-shadow-sm">{item.lastExtended}</span></div>
                </div>

                <button 
                    onClick={(e) => { e.stopPropagation(); onViewImage(item); }}
                    className="mt-3 text-[10px] bg-red-600/90 hover:bg-red-600 text-white py-1.5 px-4 rounded-full font-bold transition-all shadow-md group-hover:shadow-red-900/50"
                >
                    مشاهده تصویر کامل
                </button>
            </div>
        </div>
    );
};

export default function TrustExamples({ onNavigate }: TrustExamplesProps) {
  const [selectedImage, setSelectedImage] = useState<VisaCardData | null>(null);
  const [filter, setFilter] = useState<number | 'all'>('all');

  const filteredCards = filter === 'all' ? allCards : allCards.filter(item => item.visaId === filter);

  return (
    <div className="bg-white p-8 rounded-3xl border border-stone-100 shadow-xl space-y-8">
      <h3 className="text-xl font-black text-stone-900 text-center pb-3">نمونه اعتماد شما (ویزاها و کارت‌ها)</h3>
      
      <div className="flex flex-wrap gap-2 justify-center">
          <button onClick={() => setFilter('all')} className={`px-4 py-2 rounded-full text-[10px] sm:text-xs font-bold transition-all ${filter === 'all' ? 'bg-red-600 text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'}`}>همه</button>
          {visaItems.map(item => (
            <button key={item.id} onClick={() => setFilter(item.id)} className={`px-4 py-2 rounded-full text-[10px] sm:text-xs font-bold transition-all ${filter === item.id ? 'bg-red-600 text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'}`}>{item.title}</button>
          ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCards.map((item) => (
            <VisaCard key={item.id} item={item} onViewImage={(i) => setSelectedImage(i)} />
        ))}
      </div>
      
      <p className="text-xs text-stone-500 leading-relaxed text-center max-w-lg mx-auto pt-4 border-t border-stone-100">
        این بخش شامل نمونه‌هایی از ویزاها، کارت‌های اقامت و مدارک رسمی صادر شده برای هموطنان ما است که با رضایت آن‌ها جهت اعتمادسازی قرار داده شده است.
      </p>

      {selectedImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setSelectedImage(null)}>
            <div className="bg-white p-6 rounded-3xl max-w-xl w-full relative" onClick={e => e.stopPropagation()}>
                <button onClick={() => setSelectedImage(null)} className="absolute top-4 right-4 p-2 bg-stone-100 rounded-full hover:bg-stone-200">
                    <X className="w-5 h-5 text-stone-600" />
                </button>
                <h3 className="text-lg font-black mb-4 text-center">{selectedImage.title}</h3>
                <div className="aspect-[4/5] sm:aspect-[3/4] max-h-[60vh] bg-stone-900 rounded-2xl flex items-center justify-center overflow-hidden mb-4 border border-stone-200 shadow-inner relative group">
                    {selectedImage.imageUrl ? (
                        <img 
                            src={selectedImage.imageUrl} 
                            alt={selectedImage.title} 
                            className="w-full h-full object-contain cursor-zoom-in"
                            referrerPolicy="no-referrer"
                            onClick={() => window.open(selectedImage.imageUrl, '_blank')}
                            title="کلیک برای باز کردن تصویر در ابعاد بزرگتر"
                        />
                    ) : (
                        <span className="text-stone-400 text-xs font-bold">[تصویر یافت نشد]</span>
                    )}
                </div>
                <div className="space-y-2 text-sm text-stone-700">
                    <div className="flex justify-between border-b border-stone-100 pb-1"><span>صادرکننده:</span><span className="font-bold text-stone-900">{selectedImage.issuer}</span></div>
                    <div className="flex justify-between border-b border-stone-100 pb-1"><span>وضعیت کار:</span><span className="font-bold text-stone-900">{selectedImage.workStatus}</span></div>
                    <div className="flex justify-between"><span>آخرین تمدید:</span><span className="font-bold text-stone-900">{selectedImage.lastExtended}</span></div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
}
