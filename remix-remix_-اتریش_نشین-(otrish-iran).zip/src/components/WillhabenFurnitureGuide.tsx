import React from 'react';
import SEO from './SEO';

const WillhabenFurnitureGuide: React.FC = () => {
    return (
        <div className="p-6">
            <SEO title="راهنمای تجهیز خانه با Willhaben" description="تکنیک‌های فرنیش کردن خانه با بودجه کم از طریق پلتفرم Willhaben و روش‌های حمل نقل ارزان" />
            <h2 className="text-2xl font-black text-stone-900 mb-6">تجهیز خانه با Willhaben</h2>
            <div className="bg-stone-100 p-4 rounded-xl text-stone-600 text-sm">
                ترفندهای خرید مبلمان ارزان در اینجا قرار می‌گیرد.
            </div>
        </div>
    );
};
export default WillhabenFurnitureGuide;
