import React from 'react';
import SEO from './SEO';

const TrafficFineAppealGuide: React.FC = () => {
    return (
        <div className="p-6">
            <SEO title="راهنمای اعتراض به جرایم رانندگی" description="آموزش تفاوت جرایم رانندگی و نحوه پرداخت آنلاین جرایم و اعتراض آن‌ها" />
            <h2 className="text-2xl font-black text-stone-900 mb-6">راهنمای اعتراض به جرايم</h2>
            <div className="bg-stone-100 p-4 rounded-xl text-stone-600 text-sm">
                نحوه پرداخت جرایم و روش‌های اعتراض قانونی.
            </div>
        </div>
    );
};
export default TrafficFineAppealGuide;
