import React from 'react';
import SEO from './SEO';
import { GuideContainer } from './GuideContainer';

const SupplementalInsuranceGuide: React.FC = () => {
    return (
        <GuideContainer
            title="راهنمای بیمه تکمیلی"
            description="بررسی اهمیت بیمه تکمیلی (Zusatzversicherung) برای دسترسی سریع‌تر به خدمات لوکس پزشکی"
        >
            <SEO title="راهنمای بیمه تکمیلی اتریش" description="مقایسه انواع بیمه‌های تکمیلی (Zusatzversicherung) و مزایای استفاده از اتاق خصوصی و خدمات دندانپزشکی" />
            <div className="space-y-6">
                <div className="bg-stone-50 p-6 rounded-xl border border-stone-100">
                    <h3 className="text-xl font-bold text-stone-900 mb-2">اتاق دو نفره یا خصوصی</h3>
                    <p className="text-stone-600">امکان انتخاب پزشک متخصص و استفاده از اتاق خصوصی در بیمارستان.</p>
                </div>
                <div className="bg-stone-50 p-6 rounded-xl border border-stone-100">
                    <h3 className="text-xl font-bold text-stone-900 mb-2">خدمات دندانپزشکی</h3>
                    <p className="text-stone-600">پوشش هزینه‌های کاشت دندان و ایمپلنت که معمولاً در بیمه دولتی تحت پوشش نیستند.</p>
                </div>
            </div>
        </GuideContainer>
    );
};
export default SupplementalInsuranceGuide;
