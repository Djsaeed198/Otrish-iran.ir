import React from 'react';
import SEO from './SEO';

const WillhabenGuide: React.FC = () => {
    return (
        <div className="p-6">
            <SEO title="راهنمای جامع خرید از ویلهابن" description="آموزش اصطلاحات کلیدی و نکات امنیتی خرید و فروش در پلتفرم Willhaben" />
            <h2 className="text-2xl font-black text-stone-900 mb-6">راهنمای خرید از Willhaben</h2>
            <div className="bg-stone-100 p-4 rounded-xl text-stone-600 text-sm">
                راهنمای قدم‌به‌قدم تعامل، خرید و امنیت در پلتفرم Willhaben.
            </div>
        </div>
    );
};
export default WillhabenGuide;
