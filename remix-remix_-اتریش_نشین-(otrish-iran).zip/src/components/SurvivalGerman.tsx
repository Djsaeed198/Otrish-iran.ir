import React, { useState } from "react";
import { Play, Pause, RefreshCw, Volume2, BookOpen, Clock } from "lucide-react";

interface Phrase {
  german: string;
  phonetic: string;
  farsi: string;
  context: string;
}

interface Podcast {
  id: string;
  title: string;
  scenarioFarsi: string;
  duration: string;
  phrases: Phrase[];
}

interface Flashcard {
  id: string;
  german: string;
  phonetic: string;
  category: string;
  farsiTranslation: string;
  exampleGerman: string;
  exampleFarsi: string;
  description: string;
}

const PODCAST_TRACKS: Podcast[] = [
  {
    id: "pod1",
    title: "خرید از سوپرمارکت‌های Spar و Billa",
    scenarioFarsi: "مکالمات متداول صوتی جهت تسویه فاکتورهای صندوق و در خواست کیسه خرید یا پرداخت کارتی.",
    duration: "۳:۱۰",
    phrases: [
      { german: "Wo kann ich das Olivenöl finden?", phonetic: "وو کان ایش داس اولیون‌اُول فیندن؟", farsi: "کجا می‌توانم روغن زیتون پیدا کنم؟", context: "آدرس کالا" },
      { german: "Brauchen Sie eine Tasche?", phonetic: "براوخن زی آینه تاشه؟", farsi: "کیسه خرید نیاز دارید؟", context: "خدمات صندوق" },
      { german: "Ich möchte mit Karte zahlen, bitte.", phonetic: "ایش موخته میت کارته چالن، بیته.", farsi: "مایلم با کارت اعتباری پرداخت کنم، لطفاً.", context: "تسویه حساب" }
    ]
  },
  {
    id: "pod2",
    title: "مراجعه حضوری به شهرداری (Meldezettel)",
    scenarioFarsi: "جملات لازم برای صحبت با مأمور شهرداری (Meldeamt) جهت ثبت رسمی آدرس منزل مسکونی.",
    duration: "۲:۴۵",
    phrases: [
      { german: "Ich möchte meinen neuen Wohnsitz anmelden.", phonetic: "ایش موخته ماینن نویین وون‌زیتس آن‌ملدن.", farsi: "من می‌خواهم آدرس مسکونی جدیدم را ثبت شهرداری کنم.", context: "آغاز کار" },
      { german: "Hier ist mein Meldezettel und Reisepass.", phonetic: "هیر ایست ماین ملدتستل اوند رایزه‌پاس.", farsi: "بفرمایید این برگه ملدتستل من و پاسپورت معتبرم است.", context: "ارائه مدرک" },
      { german: "Ist diese Bestätigung kostenlos?", phonetic: "ایست دیزه بش‌تِتی‌قونک کاستن‌لوس؟", farsi: "آیا این تاییدیه رایگان است؟", context: "سوال اداری" }
    ]
  },
  {
    id: "pod3",
    title: "مراجعه به پزشک عمومی و تمدید E-Card",
    scenarioFarsi: "شرح دردهای موضعی، درخواست وقت ویزیت و ارائه بیمه سلامت عمومی اتریش ÖGK.",
    duration: "۳:۲۰",
    phrases: [
      { german: "Ich habe einen Termin um zehn Uhr.", phonetic: "ایش هابه آینن ترمین اوم ذن اور.", farsi: "من ساعت ۱۰ وقت ملاقات با پزشک دارم.", context: "پذیرش درمانگاه" },
      { german: "Hier ist meine grüne E-Card.", phonetic: "هیر ایست ماینه قرونه اِ کارت.", farsi: "بفرمایید این کارت سبز E-Card من است.", context: "بیمه سلامت" },
      { german: "Ich brauche ein Rezept für dieses Medikament.", phonetic: "ایش براوخه آین رتسپت فور دیزه مدیکامنت.", farsi: "من برای این دارو احتیاج به نسخه دارم.", context: "داروخانه عمومی" }
    ]
  }
];

const SURVIVAL_FLASHCARDS: Flashcard[] = [
  {
    id: "fc1",
    german: "Meldezettel",
    phonetic: "ملدِتستل",
    category: "امور شهرداری و اسکان",
    farsiTranslation: "برگه تاییدیه ثبت آدرس مسکونی",
    exampleGerman: "Der Meldezettel ist für das Bankkonto erforderlich.",
    exampleFarsi: "داشتن برگه ثبت آدرس مسکونی جهت افتتاح حساب بانکی اتریش اجباری است.",
    description: "مهم‌ترین و پایه‌ای‌ترین سند اداری اتریش که ظرف ۳ روز پس از نقل مکان باید به شهرداری (Magistrat) محله تسلیم کنید."
  },
  {
    id: "fc2",
    german: "Rot-Weiß-Rot - Karte",
    phonetic: "روت‌وایس‌روت کارته",
    category: "اقامت و ویزا",
    farsiTranslation: "کارت اقامت سرخ - سفید - سرخ اتریش",
    exampleGerman: "Meine RWR-Karte wurde für zwei Jahre bewilligt.",
    exampleFarsi: "کارت سرخ-سفید-سرخ من به مدت دو سال صادر (موافقت) شد.",
    description: "کارت اقامت فیزیکی موقت کاری اتریش برای متخصصین ماهر و حقوق‌های منطبق بر کاتالوگ Kollektivvertrag."
  },
  {
    id: "fc3",
    german: "E-Card",
    phonetic: "اِ کارت",
    category: "بهداشت و درمان",
    farsiTranslation: "کارت درمانی بیمه سلامت اتریش",
    exampleGerman: "Bitte zeigen Sie Ihre E-Card am Empfang.",
    exampleFarsi: "لطفاً کارت سبز درمانی خود را به باجه پذیرش نشان دهید.",
    description: "کارت ملی هوشمند بیمه همگانی پیشگیری رسمی اتریش مجهز به عکس پرسنلی و کدهای تراکنش درمانی."
  },
  {
    id: "fc4",
    german: "Grüß Gott",
    phonetic: "کرویس گات",
    category: "فرهنگ و رفتار",
    farsiTranslation: "سلام و روز خوش (رسمی و بومی اتریش)",
    exampleGerman: "Grüß Gott! Wie kann ich Ihnen heute helfen?",
    exampleFarsi: "سلام و روز خوش! چطور می‌توانم امروز کمکتان کنم؟",
    description: "مرسوم‌ترین کلمه احترام و سلام رسمی بومی اتریشی‌ها به ویژه در وین و ایالت‌های کوه آلپ بجای Guten Tag آلمانی معمولی."
  }
];

export default function SurvivalGerman() {
  const [activePodcast, setActivePodcast] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playProgress, setPlayProgress] = useState<number>(0);
  const [progressInterval, setProgressInterval] = useState<any>(null);

  // Flashcards carousel
  const [currentCardIdx, setCurrentCardIdx] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);

  const handlePlayPodcast = (id: string) => {
    if (activePodcast === id) {
      if (isPlaying) {
        clearInterval(progressInterval);
        setIsPlaying(false);
      } else {
        setIsPlaying(true);
        startSimulation();
      }
    } else {
      clearInterval(progressInterval);
      setActivePodcast(id);
      setIsPlaying(true);
      setPlayProgress(0);
      startSimulation();
    }
  };

  const startSimulation = () => {
    const interval = setInterval(() => {
      setPlayProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsPlaying(false);
          return 0;
        }
        return prev + 4;
      });
    }, 1000);
    setProgressInterval(interval);
  };

  const nextCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentCardIdx((prev) => (prev + 1) % SURVIVAL_FLASHCARDS.length);
    }, 200);
  };

  const prevCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentCardIdx((prev) => (prev - 1 + SURVIVAL_FLASHCARDS.length) % SURVIVAL_FLASHCARDS.length);
    }, 200);
  };

  const currentCard = SURVIVAL_FLASHCARDS[currentCardIdx];

  return (
    <div id="survival-german-module font-sans" className="bg-white rounded-3xl border border-stone-200 p-6 shadow-sm overflow-hidden relative text-right">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-l from-red-600 via-white to-red-600"></div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Side: Daily Admin Flashcards */}
        <div className="lg:col-span-5 space-y-4">
          <div className="space-y-1">
            <span className="text-[10px] text-red-600 font-extrabold bg-red-50 px-2 py-0.5 rounded">فلش‌کارت‌های روزانه اتریش</span>
            <h4 className="font-extrabold text-stone-850 text-sm">واژگان اداری اتریشی؛ پر تکرار در مراجع رسمی</h4>
            <p className="text-xs text-stone-400 font-bold leading-relaxed">یادگیری ۴ واژه حیاتی که روزانه در ادارات دولتی وین، Magistratها و کتب حقوقی با آن‌ها سر و کار دارید.</p>
          </div>

          {/* Interactive Card */}
          <div className="w-full aspect-[4/3] focus:outline-none">
            <div
              onClick={() => setIsFlipped(!isFlipped)}
              className="relative w-full h-full cursor-pointer h-52 bg-gradient-to-br from-stone-900 via-stone-950 to-stone-900 border border-stone-800 rounded-2xl p-6 flex flex-col justify-between text-white"
            >
              {!isFlipped ? (
                /* Card Front */
                <div className="h-full flex flex-col justify-between text-right">
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] bg-red-600 text-white font-black px-2 py-0.5 rounded shadow-xs">{currentCard.category}</span>
                    <BookOpen className="w-5 h-5 text-red-400" />
                  </div>

                  <div className="space-y-2 text-center">
                    <h2 className="text-2xl font-black tracking-wide text-amber-300 font-mono">{currentCard.german}</h2>
                    <p className="text-xs text-stone-300 font-bold font-mono">تلفظ فارسی: {currentCard.phonetic}</p>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-stone-400 font-bold">
                    <span>کلیک برای نمایش معنای واژه 🔄</span>
                    <span>کارت {currentCardIdx + 1} از {SURVIVAL_FLASHCARDS.length}</span>
                  </div>
                </div>
              ) : (
                /* Card Back */
                <div className="h-full flex flex-col justify-between text-right bg-white text-stone-800 p-2 rounded-xl">
                  <div>
                    <div className="flex justify-between items-center mb-2 border-b border-stone-100 pb-1.5">
                      <span className="text-[10px] bg-stone-100 text-stone-600 font-black px-2 py-0.5 rounded">معنا و کاربرد اتریشی</span>
                      <Volume2 className="w-4 h-4 text-stone-450" />
                    </div>
                    <h3 className="font-extrabold text-base text-red-600">{currentCard.farsiTranslation}</h3>
                    <p className="text-[11px] text-stone-500 mt-2 leading-relaxed font-bold">{currentCard.description}</p>
                  </div>

                  <div className="bg-stone-50 p-2 rounded-lg border border-stone-200 text-left" dir="ltr">
                    <p className="text-[11.5px] font-black font-mono text-stone-800 leading-normal"><strong>Bsp:</strong> {currentCard.exampleGerman}</p>
                    <p className="text-[10.5px] font-bold text-stone-550 block text-right mt-1" dir="rtl"><strong>ترجمه فارسی:</strong> {currentCard.exampleFarsi}</p>
                  </div>

                  <span className="text-[10px] text-stone-400 text-center font-bold">برای برگشت کلیک کنید 🔄</span>
                </div>
              )}
            </div>
          </div>

          {/* Carousel controls */}
          <div className="flex justify-between items-center">
            <button
              type="button"
              onClick={prevCard}
              className="bg-stone-100 hover:bg-stone-200 active:scale-95 transition-all text-xs font-bold text-stone-700 px-4 py-2 rounded-xl cursor-pointer"
            >
              کارت قبلی ←
            </button>
            <button
              type="button"
              onClick={nextCard}
              className="bg-stone-900 hover:bg-stone-800 active:scale-95 transition-all text-xs font-bold text-white px-4 py-2 rounded-xl cursor-pointer"
            >
              کارت بعدی →
            </button>
          </div>
        </div>

        {/* Right Side: 3-Minute survival podcasts */}
        <div className="lg:col-span-7 space-y-4">
          <div className="space-y-1">
            <span className="text-[10px] text-red-600 font-extrabold bg-red-50 px-2 py-0.5 rounded">راهنمای صوتی شبیه‌ساز</span>
            <h4 className="font-extrabold text-stone-850 text-lg">پادکست‌های صوتی ۳ دقیقه‌ای اتریشی 🎧</h4>
            <p className="text-xs text-stone-400 font-bold">عبارات و مکالمات کاربردی با تلفظ روان و ترجمه برای کارهای اداری، شهرداری و خرید در اتریش.</p>
          </div>

          <div className="space-y-3.5">
            {PODCAST_TRACKS.map((track) => {
              const isSelected = activePodcast === track.id;
              const isCurrentPlaying = isSelected && isPlaying;
              return (
                <div
                  key={track.id}
                  className={`border rounded-2xl p-4 transition-all ${
                    isSelected ? "bg-rose-50/20 border-red-300" : "bg-white border-stone-200 hover:border-stone-300 shadow-xs"
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <button
                      onClick={() => handlePlayPodcast(track.id)}
                      className={`w-9 h-9 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                        isCurrentPlaying ? "bg-red-600 text-white animate-pulse" : "bg-stone-100 hover:bg-red-50 hover:text-red-600 text-stone-600"
                      }`}
                    >
                      {isCurrentPlaying ? "⏸" : "▶"}
                    </button>

                    <div className="flex-1 text-right">
                      <div className="flex items-center gap-1.5 justify-end">
                        <span className="text-[10px] text-stone-400 font-mono flex items-center gap-1">
                          {track.duration} دقیقه <Clock className="w-3.5 h-3.5" />
                        </span>
                        <h5 className="font-extrabold text-xs text-stone-800">{track.title}</h5>
                      </div>
                      <p className="text-[11px] text-stone-400 font-bold mt-1">
                        {track.scenarioFarsi}
                      </p>
                    </div>
                  </div>

                  {isSelected && (
                    <div className="mt-4 pt-3 border-t border-stone-100 space-y-3 animate-fade-in">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-stone-200 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-red-600 h-full transition-all duration-300" style={{ width: `${playProgress}%` }}></div>
                        </div>
                        <span className="text-[9px] font-black text-stone-400 font-mono mt-0.5">{playProgress ? `${Math.round(playProgress)}%` : "۰:۰۰"}</span>
                      </div>

                      <div className="space-y-3 pt-1">
                        <h6 className="text-[10px] font-extrabold text-red-700 bg-red-100/60 p-1.5 rounded inline-block">مهم‌ترین عبارات صوتی این پادکست:</h6>
                        <div className="grid grid-cols-1 gap-2">
                          {track.phrases.map((ph, idx) => (
                            <div key={idx} className="bg-white border border-stone-150 p-2.5 rounded-xl space-y-1 text-right">
                              <span className="text-[9px] bg-stone-100 text-stone-600 font-bold px-1.5 py-0.5 rounded-md inline-block">{ph.context}</span>
                              <p className="text-xs font-black font-mono text-stone-800 text-left select-all" dir="ltr">{ph.german}</p>
                              <p className="text-[10px] font-bold text-red-500">تلفظ فارسی: {ph.phonetic}</p>
                              <p className="text-[10px] font-bold text-stone-500">ترجمه به فارسی: {ph.farsi}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* AUSTRIAN DIALECT DICTIONARY SECTION */}
      <div className="mt-12 pt-8 border-t border-stone-200 space-y-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-right">
            <span className="text-[10px] text-red-650 font-black bg-rose-100 rounded px-2.5 py-0.5">Österreichisches Wörterbuch</span>
            <h4 className="font-extrabold text-stone-850 text-base sm:text-lg mt-1 flex items-center justify-end md:justify-start gap-2">
              <span>دیکشنری گویش و لهجه اصیل اتریشی (Österreichisches Deutsch) 🇦🇹</span>
            </h4>
            <p className="text-xs text-stone-400 font-bold mt-1">
              واژگان، خوراکی‌ها، اصطلاحات عامیانه و ترابری وین و ایالت‌های کوهستان آلپ که با زبان رسمی آلمان تفاوت دارند
            </p>
          </div>

          <span className="text-[10px] bg-amber-50 text-amber-800 border border-amber-200 rounded px-3 py-1 font-bold">
            مجهز به تلفظ صوتی با لهجه وین (de-AT) 🔊
          </span>
        </div>

        {/* Search and Category Filter block */}
        <DictionaryBlock />
      </div>
    </div>
  );
}

// Sub-component for Dictionary state management inside SurvivalGerman
function DictionaryBlock() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState('all');

  const terms = [
    {
      word: 'Sackerl',
      hochdeutsch: 'Papiertüte / Plastiktüte',
      translation: 'کیسه یا پلاستیک خرید رایج',
      pronunciation: 'زاکِرل',
      category: 'shopping',
      example: 'Brauchen Sie ein Sackerl für Ihren Einkauf?',
      trivia: 'در آلمان به کیسه خرید Tüte می‌گویند اما در سوپر‌های اتریش (Spar, Billa) هربار صندوقدار از شما Sackerl تقاضا خواهد کرد.',
      imageSeed: 'shopping-bag'
    },
    {
      word: 'Paradeiser',
      hochdeutsch: 'Tomate',
      translation: 'گوجه‌فرنگی',
      pronunciation: 'پارادایسر',
      category: 'food',
      example: 'Ich kaufe ein Kilo Paradeiser auf dem Naschmarkt.',
      trivia: 'این کلمه برگرفته از واژه بهشت (Paradies) است. در تمام برچسب‌های قیمتی تره‌بار اتریش به جای Tomate این واژه درج شده است.',
      imageSeed: 'tomatoes'
    },
    {
      word: 'Erdapfel',
      hochdeutsch: 'Kartoffel',
      translation: 'سیب‌زمینی',
      pronunciation: 'اِردآپفل',
      category: 'food',
      example: 'Erdäpfelsalat ist eine typische österreichische Beilage.',
      trivia: 'ترجمه تحت‌اللفظی آن «سیب روی زمین» است (شبیه به اصطلاح فرانسوی Pomme de terre). سالاد سیب‌زمینی اتریش شهرت جهانی دارد.',
      imageSeed: 'potatoes'
    },
    {
      word: 'Bim',
      hochdeutsch: 'Straßenbahn',
      translation: 'تراموا / قطار درون‌شهری روی ریل',
      pronunciation: 'بیم',
      category: 'transport',
      example: 'Fährt diese Bim direkt zum Westbahnhof?',
      trivia: 'یک کلمه مخفف شیرین و کاملاً اتریشی! به علت صدای مکرر بوق و زنگ قدیمی واگن‌ها (بیم-بیم) به این نام مشهور گشته است.',
      imageSeed: 'tram'
    },
    {
      word: 'Obers',
      hochdeutsch: 'Sahne',
      translation: 'خامه صبحانه یا آشپزی',
      pronunciation: 'اُبرس',
      category: 'food',
      example: 'Ein Melange mit Schlagobers, bitte.',
      trivia: 'اتریشی‌ها هیچ‌گاه کلمه Schlagsahne آلمانی را به کار نمی‌برند. در منوی کافه‌های وین همواره Schlagobers (خامه زده شده) می‌بینید.',
      imageSeed: 'whipped-cream'
    },
    {
      word: 'Jänner',
      hochdeutsch: 'Januar',
      translation: 'ژانویه (اولین ماه سال میلادی)',
      pronunciation: 'یِنِر',
      category: 'calendar',
      example: 'Der Kurs beginnt am ersten Jänner.',
      trivia: 'تنها ماه سررسید میلادی که در حقوق رسمی و قراردادهای دولتی اتریش با آلمانی معیار کشور آلمان فرق داشته و کلمه‌ای اختصاصی است.',
      imageSeed: 'january-calendar'
    },
    {
      word: 'heuer',
      hochdeutsch: 'dieses Jahr',
      translation: 'امسال / در سال جاری',
      pronunciation: 'هویا',
      category: 'slang',
      example: 'Wir haben heuer einen sehr milden Winter in Wien.',
      trivia: 'کلمه‌ای پرکاربرد در جنوب آلمان و اتریش برای توصیف اتفاقات سال جاری که در بخش غربی آلمان کمتر شنیده می‌شود.',
      imageSeed: 'this-year-calendar'
    },
    {
      word: 'Servus',
      hochdeutsch: 'Hallo / Tschüss',
      translation: 'سلام و هم خداحافظ صمیمی',
      pronunciation: 'سِرووس',
      category: 'greeting',
      example: 'Servus Michael! Wie geht es dir?',
      trivia: 'برگرفته از واژه لاتین به کنایه از «در خدمت شما هستم». در تمام پاتوق‌ها و دیدارهای جوانان رواج درجه یک دارد.',
      imageSeed: 'greeting-handshake'
    },
    {
      word: 'leiwand',
      hochdeutsch: 'toll / super',
      translation: 'معرکه، باحال، عالی یا باکیفیت',
      pronunciation: 'لای‌واند',
      category: 'slang',
      example: 'Das neue Klimaticket ist wirklich leiwand!',
      trivia: 'اصطلاح چیره و اصیل لهجه وینی که برای نشان دادن نهایت رضایت و لذت عمیق از یک رویداد یا کالا از ته دل استفاده می‌شود.',
      imageSeed: 'awesome-vienna'
    },
    {
      word: 'ur-',
      hochdeutsch: 'sehr / extrem',
      translation: 'خیلی، فوق‌العاده، به شدت زیاد',
      pronunciation: 'اور',
      category: 'slang',
      example: 'Das Konzert gestern war ur-leiwand!',
      trivia: 'به عنوان پیشوند به تمام صفت‌ها متصل می‌گردد تا بار معنایی آن را تشدید کند؛ مانند ur-kalt (بسیار سرد).',
      imageSeed: 'extreme-intensity'
    },
    {
      word: 'Melange',
      hochdeutsch: 'Kaffee mit Milch',
      translation: 'قهوه‌ی سنتی وینی کف‌دار',
      pronunciation: 'ملانش',
      category: 'food',
      example: 'Ich trinke gerne eine Wiener Melange im Café.',
      trivia: 'نوشیدنی نمادین وین که مخلوطی از قهوه اسپرسو داغ و کف شیر غلیظ پرچرب است و نماد فرهنگ قهوه‌خانه‌نشینی اتریش است.',
      imageSeed: 'melange-coffee'
    },
    {
      word: 'Beisl',
      hochdeutsch: 'Kneipe / Wirtshaus',
      translation: 'مسافرخانه یا کافه سنتی کوچک برای تره‌بار',
      pronunciation: 'بایزل',
      category: 'places',
      example: 'Am Abend gehen wir in ein gemütliches Wiener Beisl.',
      trivia: 'اماکنی بومی و دنج که غذاهای محلی ارزان مانند اشنیتسل را همراه آبجو ارائه می‌دهند و بسیار صمیمی هستند.',
      imageSeed: 'traditional-pub'
    },
    {
      word: 'Semmel',
      hochdeutsch: 'Brötchen',
      translation: 'نان گرد کوچک',
      pronunciation: 'زِمِل',
      category: 'food',
      example: 'Ich hätte gerne zwei Semmeln.',
      trivia: 'پر مصرف‌ترین نان اتریش برای صبحانه و شام.',
      imageSeed: 'bread-roll'
    },
    {
      word: 'Jause',
      hochdeutsch: 'Zwischenmahlzeit',
      translation: 'میان‌وعده',
      pronunciation: 'یاوزه',
      category: 'food',
      example: 'Es ist Zeit für eine kleine Jause.',
      trivia: 'میان‌وعده‌ای که هر اتریشی معمولاً حدود ساعت ۱۰ صبح یا ۴ بعدازظهر می‌خورد.',
      imageSeed: 'snack-time'
    },
    {
      word: 'Kassierin',
      hochdeutsch: 'Kassiererin',
      translation: 'صندوقدار (زن)',
      pronunciation: 'کاسیرین',
      category: 'shopping',
      example: 'Die Kassierin war sehr freundlich.',
      trivia: 'در اکثر سوپرمارکت‌ها با این جایگاه مواجه خواهید شد.',
      imageSeed: 'cashier-woman'
    },
    {
      word: 'U-Bahn',
      hochdeutsch: 'Untergrundbahn',
      translation: 'مترو',
      pronunciation: 'او-بان',
      category: 'transport',
      example: 'Die U-Bahn kommt in zwei Minuten.',
      trivia: 'سریع‌ترین وسیله نقلیه عمومی در وین.',
      imageSeed: 'metro-train'
    },
    {
      word: 'Fahrkarten',
      hochdeutsch: 'Tickets',
      translation: 'بلیت‌ها',
      pronunciation: 'فار-کارتن',
      category: 'transport',
      example: 'Wo kann ich Fahrkarten kaufen?',
      trivia: 'واژه‌ای ضروری برای استفاده از وسایل نقلیه.',
      imageSeed: 'tickets-machine'
    },
    {
      word: 'Rathaus',
      hochdeutsch: 'Stadthaus',
      translation: 'شهرداری',
      pronunciation: 'رات-هاوس',
      category: 'places',
      example: 'Das Rathaus von Wien ist prachtvoll.',
      trivia: 'مرکز اصلی امور اداری شهر.',
      imageSeed: 'city-hall-vienna'
    },
    {
      word: 'Gasthaus',
      hochdeutsch: 'Restaurant',
      translation: 'رستوران / مسافرخانه',
      pronunciation: 'گاست-هاوس',
      category: 'places',
      example: 'Wir essen im Gasthaus zu Mittag.',
      trivia: 'مکان مناسب برای صرف غذای خانگی.',
      imageSeed: 'austrian-restaurant'
    },
    {
      word: 'Gemütlich',
      hochdeutsch: 'behaglich',
      translation: 'دنج و راحت',
      pronunciation: 'گه-موت-لیش',
      category: 'culture',
      example: 'Es ist sehr gemütlich hier.',
      trivia: 'حس رفاه و راحتی در یک محیط.',
      imageSeed: 'cozy-atmosphere'
    },
    {
      word: 'Tschüss',
      hochdeutsch: 'Auf Wiedersehen',
      translation: 'خداحافظ',
      pronunciation: 'چوس',
      category: 'slang',
      example: 'Tschüss, bis morgen!',
      trivia: 'خداحافظی دوستانه و غیررسمی.',
      imageSeed: 'friendly-goodbye'
    },
    {
      word: 'Passt',
      hochdeutsch: 'Das ist in Ordnung',
      translation: 'باشه / مناسبه',
      pronunciation: 'پاست',
      category: 'slang',
      example: 'Passt, machen wir so.',
      trivia: 'برای توافق و تأیید استفاده می‌شود.',
      imageSeed: 'agreement-thumbsup'
    }
  ];

  const handleSpeak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'de-AT'; // Explicitly requests Austrian accent
      
      const voices = window.speechSynthesis.getVoices();
      // Try finding Austrian or German voice
      const atVoice = voices.find(v => v.lang.toLowerCase().includes('at'));
      const deVoice = voices.find(v => v.lang.toLowerCase().includes('de'));
      
      if (atVoice) {
        utterance.voice = atVoice;
      } else if (deVoice) {
        utterance.voice = deVoice;
      }
      
      window.speechSynthesis.speak(utterance);
    }
  };

  const filtered = terms.filter(item => {
    const matchesSearch = item.word.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.hochdeutsch.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.translation.includes(searchQuery);
    
    const matchesCat = selectedCat === 'all' || item.category === selectedCat;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-4">
      {/* Search Input and Categories tabs */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
        <div className="md:col-span-5 relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="جستجوی لغت اتریشی، معادل آلمانی معیار یا معنای فرعی..."
            className="w-full bg-stone-50 border border-stone-200 p-2.5 rounded-xl text-xs outline-none focus:border-red-400 font-bold"
          />
        </div>

        <div className="md:col-span-12 lg:col-span-7 flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'all', name: '🌸 همه اصطلاحات' },
            { id: 'greeting', name: '👋 احوال‌پرسی' },
            { id: 'food', name: '🍏 سوپرمارکت و غذا' },
            { id: 'shopping', name: '🛒 خرید بومی' },
            { id: 'transport', name: '🚇 ترابری و آدرس' },
            { id: 'slang', name: '💬 اصطلاحات خیابانی' },
            { id: 'places', name: '📍 کافه و پاتوق‌ها' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSelectedCat(tab.id)}
              className={`px-3 py-1.5 rounded-lg border text-[11px] font-black shrink-0 transition-all cursor-pointer ${
                selectedCat === tab.id
                  ? 'bg-rose-600 border-red-750 text-white shadow-xs'
                  : 'bg-white border-stone-150 text-stone-600 hover:bg-stone-50'
              }`}
            >
              {tab.name}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Results */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.length > 0 ? (
          filtered.map((item, idx) => (
            <div key={idx} className="relative overflow-hidden bg-white/90 backdrop-blur-sm border border-stone-150 rounded-2xl p-4.5 transition-colors hover:border-red-300 flex flex-col justify-between text-right space-y-3.5 shadow-3xs">
              <div className="absolute inset-0 z-0 bg-cover bg-center opacity-20" style={{ backgroundImage: `url('https://picsum.photos/seed/${item.imageSeed}/400/600')` }}></div>
              
              <div className="relative z-10 space-y-3.5">
              <div className="absolute top-0 right-0 w-1 bg-red-650 h-full"></div>
              
              <div className="space-y-1 pr-1">
                <div className="flex justify-between items-start">
                  <button
                    onClick={() => handleSpeak(item.word)}
                    className="w-7 h-7 bg-white/80 hover:bg-red-50 text-stone-605 hover:text-red-700 rounded-full flex items-center justify-center cursor-pointer transition-colors"
                    title="پخش تلفظ صوتی با گویش اتریش"
                  >
                    🔊
                  </button>
                  <h5 className="font-extrabold text-stone-900 text-sm md:text-base font-mono bg-white/50 px-2 rounded">{item.word}</h5>
                </div>

                <div className="text-[10px] text-stone-600 font-bold font-mono bg-white/50 px-2 py-0.5 rounded">
                  معادل استاندارد آلمان: <span className="font-black text-stone-800">{item.hochdeutsch}</span>
                </div>
              </div>

              <div className="p-2.5 bg-white/70 rounded-lg border border-stone-150 text-right pr-3 space-y-1">
                <span className="text-[10px] text-red-650 bg-red-50/80 px-1 rounded font-black inline-block">معنی فارسی:</span>
                <p className="text-xs font-bold text-stone-900">{item.translation}</p>
                <p className="text-[10px] text-stone-500 font-bold">تلفظ: {item.pronunciation}</p>
              </div>

              <div className="text-left" dir="ltr">
                <p className="text-[11px] font-bold text-stone-700 italic bg-white/50 px-2 rounded">Example: "{item.example}"</p>
              </div>

              <p className="text-[10.5px] text-stone-700 leading-relaxed font-semibold pt-1 border-t border-stone-100 bg-white/50 px-2 rounded">
                💡 <strong>فکت تاریخی بومی:</strong> {item.trivia}
              </p>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center p-8 text-stone-400 text-xs font-bold bg-stone-50/50 border border-stone-150 rounded-2xl">
            واژه‌ای مطابق با فیلتر شما یافت نشد. عبارت دیگر پیست فرمایید.
          </div>
        )}
      </div>
    </div>
  );
}

