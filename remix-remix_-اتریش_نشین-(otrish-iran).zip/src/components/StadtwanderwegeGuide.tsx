import React from 'react';
import SEO from './SEO';

const StadtwanderwegeGuide: React.FC = () => {
    return (
        <div className="p-6">
            <SEO title="راهنمای مسیرهای پیاده‌روی وین" description="معرفی ۱۴ مسیر رسمی پیاده‌روی شهری وین در طبیعت و جنگل" />
            <h2 className="text-2xl font-black text-stone-900 mb-6">مسیرهای پیاده‌روی وین</h2>
            <div className="bg-stone-100 p-4 rounded-xl text-stone-600 text-sm">
                نقشه مسیرهای پیاده‌روی شهری در اینجا قرار می‌گیرد.
            </div>
        </div>
    );
};
export default StadtwanderwegeGuide;
