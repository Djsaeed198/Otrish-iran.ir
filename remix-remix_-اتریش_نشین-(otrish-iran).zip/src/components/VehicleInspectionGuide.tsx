import React from 'react';
import SEO from './SEO';

const VehicleInspectionGuide: React.FC = () => {
    return (
        <div className="p-6">
            <SEO title="راهنمای معاینه فنی خودرو (Pickerl)" description="قوانین و شرایط انجام معاینه فنی خودرو در اتریش" />
            <h2 className="text-2xl font-black text-stone-900 mb-6">معاینه فنی خودرو</h2>
            <div className="bg-stone-100 p-4 rounded-xl text-stone-600 text-sm">
                مقررات و مراکز انجام معاینه فنی (Pickerl).
            </div>
        </div>
    );
};
export default VehicleInspectionGuide;
