import React from 'react';
import SEO from './SEO';

const WifiBfiGuide: React.FC = () => {
    return (
        <div className="p-6">
            <SEO title="راهنمای دوره‌های WIFI و bfi" description="راهنمای ثبت‌نام دوره‌های فنی‌وحرفه‌ای و دریافت فاند آموزشی WAFF" />
            <h2 className="text-2xl font-black text-stone-900 mb-6">راهنمای دوره‌های WIFI و bfi</h2>
            <div className="bg-stone-100 p-4 rounded-xl text-stone-600 text-sm">
                لیست دوره‌ها و نحوه استفاده از فاند آموزشی.
            </div>
        </div>
    );
};
export default WifiBfiGuide;
