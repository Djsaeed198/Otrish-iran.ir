import React, { useState } from 'react';
import { Info } from 'lucide-react';

export default function WohnbeihilfeBlock() {
  const [houseSize, setHouseSize] = useState<string>('65');
  const [occupants, setOccupants] = useState<number>(2);
  const [householdIncome, setHouseholdIncome] = useState<string>('1800');
  const [wohnResult, setWohnResult] = useState<{
    eligible: boolean;
    amount: number;
    text: string;
  } | null>(null);

  const calculateWohnbeihilfe = (e: React.FormEvent) => {
    e.preventDefault();
    const size = parseFloat(houseSize);
    const income = parseFloat(householdIncome);

    if (isNaN(size) || isNaN(income)) return;

    // Vienna rules guidelines: 
    // Max size allowed for subsidy: 1 person = 50m², 2 people = 70m², 3+ people = 80m²
    const maxRepresentativeSize = occupants === 1 ? 50 : occupants === 2 ? 70 : 80;
    const sizeToUse = Math.min(size, maxRepresentativeSize);

    // Max subsidy is based on monthly rent baseline (e.g. €8.50 per m² standard maximum reference rent)
    const referenceRent = sizeToUse * 8.5;

    // Minimum reasonable own contribution goes up progressively based on net family income
    // Example formula: Zumutbarer Eigenaufwand gets larger when income gets higher
    const survivalRate = occupants * 650; // Simple baseline cost multiplier
    let reasonableContribution = 0;

    if (income > survivalRate) {
      reasonableContribution = (income - survivalRate) * 0.35 + (occupants * 150);
    } else {
      reasonableContribution = occupants * 120;
    }

    const estimatedSubsidy = Math.round(Math.max(0, referenceRent - reasonableContribution));

    if (estimatedSubsidy > 20 && income < (occupants * 1300)) {
      setWohnResult({
        eligible: true,
        amount: estimatedSubsidy,
        text: `تبریک! شما واجد شرایط دریافت تخمینی حدود **${estimatedSubsidy.toLocaleString('fa-IR')} یورو** در شهریه ماهانه از شهرداری (بخش MA 50 مسکن) هستید.`
      });
    } else {
      setWohnResult({
        eligible: false,
        amount: 0,
        text: "متاسفانه بر اساس سقف درآمد ثبت شده یا بالا بودن میزان درآمد خانواده نسبت به متراژ، در محدوده پرداخت یارانه مسکن شهرداری قرار ندارید."
      });
    }
  };

  return (
    <section className="bg-gradient-to-tr from-rose-50/50 via-white to-red-50/30 border border-rose-200 p-8 md:p-12 rounded-[36px] relative overflow-hidden shadow-xs" id="wohnbeihilfe-block">
      <div className="absolute top-0 left-0 w-44 h-44 rounded-full bg-red-650/5 blur-xl"></div>
      
      <div className="relative z-10">
        <div className="max-w-2xl text-right space-y-3 mb-8">
          <span className="bg-red-50 text-red-700 text-[10px] font-black px-3 py-1 border border-red-100 rounded-full inline-block shadow-3xs">
            MUNICIPAL HOUSING AID
          </span>
          <h3 className="font-extrabold text-stone-850 text-base sm:text-md">ماشین‌حساب کمک‌هزینه مسکن شهرداری اتریش (Wohnbeihilfe)</h3>
          <p className="text-xs text-stone-500 leading-relaxed font-bold">
            آیا می‌دانید شهرداری وین (از طریق بخش مسکن MA 50) با توجه به تعداد افراد خانواده، متراژ قانونی خانه مجهز به ملده و میزان درآمد نتو، بخشی از اجاره ماهیانه شما را پرداخت می‌کند؟ شانس دقیق خود را با فرمول لایو محاسبه کنید:
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Input fields */}
          <form onSubmit={calculateWohnbeihilfe} className="lg:col-span-7 bg-white/75 border border-stone-200/70 p-6 md:p-8 rounded-[30px] grid grid-cols-1 sm:grid-cols-2 gap-4 text-right">
            <div>
              <label htmlFor="wh-size" className="text-[10px] font-black text-stone-600 block mb-1">متراژ مسکن (مترمربع - m²):</label>
              <input 
                id="wh-size"
                type="number"
                required
                value={houseSize}
                onChange={(e) => setHouseSize(e.target.value)}
                placeholder="مثلا: ۶۵"
                className="w-full bg-stone-50 border border-stone-200 p-2.5 rounded-xl font-mono text-xs text-left text-stone-900 outline-none focus:border-red-400"
              />
            </div>

            <div>
              <label htmlFor="wh-occupants" className="text-[10px] font-black text-stone-650 block mb-1">تعداد افراد ساکن مجهز به ملده:</label>
              <select 
                id="wh-occupants"
                value={occupants}
                onChange={(e) => setOccupants(Number(e.target.value))}
                className="w-full bg-stone-50 border border-stone-200 p-2.5 rounded-xl text-xs outline-none cursor-pointer text-stone-800"
              >
                <option value={1}>۱ نفر</option>
                <option value={2}>۲ نفر</option>
                <option value={3}>۳ نفر یا بیشتر</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="wh-income" className="text-[10px] font-black text-stone-600 block mb-1">مجموع درآمد خالص ماهیانه متقاضیان (یورو):</label>
              <div className="relative">
                <input 
                  id="wh-income"
                  type="number"
                  required
                  value={householdIncome}
                  onChange={(e) => setHouseholdIncome(e.target.value)}
                  placeholder="مثلا: ۱۸۰۰"
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 px-8 rounded-xl font-mono text-xs text-left text-stone-900 outline-none focus:border-red-400"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-stone-400">€</span>
              </div>
            </div>

            <button 
              type="submit"
              className="sm:col-span-2 bg-[#1727b5] hover:bg-[#1727b5]/90 text-white text-xs font-black p-3.5 rounded-2xl cursor-pointer shadow-sm hover:scale-[1.01] transition-transform active:scale-98"
            >
              بررسی صلاحیت دریافت کمک‌هزینه Wohnbeihilfe
            </button>
          </form>

          {/* Results card */}
          <div className="lg:col-span-5 flex flex-col justify-between gap-4">
            
            <div className="bg-white border border-stone-200 p-5 rounded-2.5xl flex items-start gap-4">
              <div className="w-10 h-10 bg-amber-50 text-amber-700 rounded-xl flex items-center justify-center shrink-0">
                <Info className="w-5 h-5" />
              </div>
              <div className="text-right">
                <h4 className="text-[11px] font-black text-stone-850">شرط سنوات اقامت قانونی</h4>
                <p className="text-[9.5px] text-stone-500 leading-normal">برای دریافت این کمک‌هزینه در وین، باید حداقل ۲ سال سابقه ملده فعال در اتریش داشته باشید.</p>
              </div>
            </div>

            {wohnResult ? (
              <div className={`p-5 rounded-2.5xl border text-right space-y-2 animate-fade-in ${
                wohnResult.eligible ? 'bg-emerald-500/5 border-emerald-200 text-stone-900' : 'bg-rose-500/5 border-rose-200 text-stone-900'
              }`}>
                <h4 className={`text-xs font-black ${wohnResult.eligible ? 'text-emerald-800' : 'text-rose-800'}`}>
                  {wohnResult.eligible ? '✓ واجد شرایط تخمینی' : '× عدم تطابق با الگو'}
                </h4>
                <p className="text-[10.5px] leading-relaxed font-bold text-stone-700">
                  {wohnResult.text}
                </p>
              </div>
            ) : (
              <div className="p-5 bg-stone-50 border border-stone-200 rounded-2.5xl text-center text-xs text-stone-400 font-bold italic h-full flex items-center justify-center">
                برای برآورد استعلام صلاحیت مبالغ، دکمه فرم چپ را فشار دهید.
              </div>
            )}

          </div>
        </div>
      </div>
    </section>
  );
}
