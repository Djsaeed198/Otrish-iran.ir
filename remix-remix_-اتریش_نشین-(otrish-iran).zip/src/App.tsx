import React, { useState, useEffect, lazy, Suspense } from "react";
import {
  Compass,
  Coins,
  Map,
  BookOpen,
  Users,
  MessageSquare,
  Sparkles,
  CloudSun,
  ShieldCheck,
  AlertOctagon,
  ChevronLeft,
  Calendar,
  Home,
  Clock,
  MapPin,
  Send,
  Instagram,
  Facebook,
  Phone,
  ExternalLink,
  Award,
  Calculator,
  Newspaper,
  RefreshCw,
  Share2,
  BarChart3,
  FileText,
  GraduationCap,
  Globe,
  UserCheck,
  CheckCircle,
  ShoppingBag,
  Heart,
  Building,
  Car,
  ShoppingCart,
  Train,
  Smile,
  Stethoscope,
  Ticket,
  Search
} from "lucide-react";

// In App function:
// const [language, setLanguage] = useState<'fa' | 'de'>('fa');
// ...
// Add toggle to header

// Static imports for initial Home Segment components (for zero-CLS instant rendering)
import ExperienceGallery from "./components/ExperienceGallery";
import ComparisonWizard from "./components/ComparisonWizard";
import AdministrativeGlossary from "./components/AdministrativeGlossary";
import VisaSuitabilityWizard from "./components/VisaSuitabilityWizard";
import CostOfLivingComparison from "./components/CostOfLivingComparison";
import FormDownloadLibrary from "./components/FormDownloadLibrary";
import SchoolDirectory from "./components/SchoolDirectory";
import VisaCalculator from "./components/VisaCalculator";
import ExchangeRateWidget from "./components/ExchangeRateWidget";
import InsuranceFilterDirectory from "./components/InsuranceFilterDirectory";
import DistrictGuide from "./components/DistrictGuide";
import ExpertProfile from "./components/ExpertProfile";
import TranslatorDirectory from "./components/TranslatorDirectory";
import FactCheckArticles from "./components/FactCheckArticles";
import NoVACalculator from "./components/NoVACalculator";
import OfferDirectory from "./components/OfferDirectory";
import StudentFinanceCalculator from "./components/StudentFinanceCalculator";
import WillhabenGuide from "./components/WillhabenGuide";
import NeighborhoodComparison from "./components/NeighborhoodComparison";
import VolunteerDirectory from "./components/VolunteerDirectory";
import PublicHolidayCalendar from "./components/PublicHolidayCalendar";
import DrivingLicenseGuide from "./components/DrivingLicenseGuide";
import RealEstateTaxCalculator from "./components/RealEstateTaxCalculator";
import InsuranceSupplementalGuide from "./components/InsuranceSupplementalGuide";
import IdAustriaGuide from "./components/IdAustriaGuide";
import TaxRegistrationGuide from "./components/TaxRegistrationGuide";
import CriminalRecordGuide from "./components/CriminalRecordGuide";
import NostrificationGuide from "./components/NostrificationGuide";
import BankExchangeDirectory from "./components/BankExchangeDirectory";
import MoneyLaunderingInfo from "./components/MoneyLaunderingInfo";
import PublicTransportGuide from "./components/PublicTransportGuide";
import VehicleInspectionGuide from "./components/VehicleInspectionGuide";
import ParkingGuide from "./components/ParkingGuide";
import GroceryDirectory from "./components/GroceryDirectory";
import ShoppingGuide from "./components/ShoppingGuide";
import ChristmasMarketGuide from "./components/ChristmasMarketGuide";
import DanubeFestivalGuide from "./components/DanubeFestivalGuide";
import SkiResortGuide from "./components/SkiResortGuide";
import PoolTicketGuide from "./components/PoolTicketGuide";
import TheoryExamTest from "./components/TheoryExamTest";
import MA35AppointmentGuide from "./components/MA35AppointmentGuide";
import CitizenshipGuide from "./components/CitizenshipGuide";
import BankComparisonGuide from "./components/BankComparisonGuide";
import KindergartenGuide from "./components/KindergartenGuide";
import SupplementalInsuranceGuide from "./components/SupplementalInsuranceGuide";
import PensionGuide from "./components/PensionGuide";
import LiabilityInsuranceGuide from "./components/LiabilityInsuranceGuide";
import WillhabenSecurityGuide from "./components/WillhabenSecurityGuide";
import OrganicMarketsGuide from "./components/OrganicMarketsGuide";
import HalalDirectory from "./components/HalalDirectory";
import MarriageDivorceGuide from "./components/MarriageDivorceGuide";
import TaxReturnGuide from "./components/TaxReturnGuide";
import FreelanceTaxHub from "./components/FreelanceTaxHub";
import FamilienbonusGuide from "./components/FamilienbonusGuide";
import WifiBfiGuide from "./components/WifiBfiGuide";
import AccountingCareerGuide from "./components/AccountingCareerGuide";
import KlimaTicketGuide from "./components/KlimaTicketGuide";
import TrafficFineAppealGuide from "./components/TrafficFineAppealGuide";
import RWRPunterRechner from "./components/RWRPunterRechner";
import ResidencyConditionGuide from "./components/ResidencyConditionGuide";
import StudentGradRelocationGuide from "./components/StudentGradRelocationGuide";
import WillhabenFurnitureGuide from "./components/WillhabenFurnitureGuide";
import DiscounterGuide from "./components/DiscounterGuide";
import ObbVorteilscardGuide from "./components/ObbVorteilscardGuide";
import ContractCancellationGuide from "./components/ContractCancellationGuide";
import BetriebskostenGuide from "./components/BetriebskostenGuide";
import MutterKindPassGuide from "./components/MutterKindPassGuide";
import KassenarztDirectory from "./components/KassenarztDirectory";
import EmergencyDentistryGuide from "./components/EmergencyDentistryGuide";
import OperaStandingTicketGuide from "./components/OperaStandingTicketGuide";
import StadtwanderwegeGuide from "./components/StadtwanderwegeGuide";
import IdAustriaActivationGuide from "./components/IdAustriaActivationGuide";
import PhishingSecurityGuide from "./components/PhishingSecurityGuide";
import AustriaMainDashboard from "./components/AustriaMainDashboard";
import EcosystemPortal from "./components/EcosystemPortal";
import WelcomeNotification from "./components/WelcomeNotification";
import { trackEvent } from "./utils/tracker";
import BruttoNettoCalculator from "./components/BruttoNettoCalculator";
import InterpreterAcademy from "./components/InterpreterAcademy";
import WohnbeihilfeBlock from "./components/WohnbeihilfeBlock";
import AustriaClassifiedsBlock from "./components/AustriaClassifiedsBlock";
import AustriaIranNewsBanner from "./components/AustriaIranNewsBanner";
import NewsModal from "./components/NewsModal";
import SEO from "./components/SEO";
import ImmigrationAssessment from "./components/ImmigrationAssessment";
import ToastNotification from "./components/ToastNotification";
import { toast } from "./utils/toast";
import { motion, AnimatePresence } from "motion/react";
import WhatsAppConsultButton from "./components/WhatsAppConsultButton";
import SuperAppHeader from "./components/SuperAppHeader";
import SuperAppLauncher from "./components/SuperAppLauncher";
import SuperAppPageLayout from "./components/SuperAppPageLayout";
import SuperAppSearchModal from "./components/SuperAppSearchModal";
import SuperAppMobileBottomNav from "./components/SuperAppMobileBottomNav";
/* ... imports ... */
import MobileNavigationDrawer from "./components/MobileNavigationDrawer";
import LiveNewsTicker from "./components/LiveNewsTicker";

// Navigation pages configuration
const NAV_PAGES = [
  { id: "home", label: "صفحه اصلی", icon: Home },
  { id: "stories", label: "تجربه‌سرا", icon: BookOpen },
  { id: "compare", label: "مقایسه اقامت", icon: ShieldCheck },
  { id: "glossary", label: "واژه‌نامه", icon: BookOpen },
  { id: "compare-living", label: "مقایسه هزینه", icon: BarChart3 },
  { id: "forms", label: "فرم‌های اداری", icon: FileText },
  { id: "schools", label: "مدارس", icon: GraduationCap },
  { id: "calculator", label: "امتیاز ویزا", icon: Sparkles },
  { id: "exchange", label: "نرخ ارز", icon: Coins },
  { id: "insurance", label: "بیمه پزشکان", icon: ShieldCheck },
  { id: "district", label: "راهنمای محلات", icon: Map },
  { id: "nova", label: "مالیات خودرو", icon: Car },
  { id: "offers", label: "تخفیف‌ها", icon: Coins },
  { id: "student-finance", label: "وام دانشجویی", icon: GraduationCap },
  { id: "willhaben", label: "خرید دست‌دوم", icon: ShoppingBag },
  { id: "neighborhood", label: "مقایسه محلات", icon: Map },
  { id: "volunteer", label: "کارهای خیر", icon: Heart },
  { id: "holidays", label: "تعطیلات رسمی", icon: Calendar },
  { id: "license", label: "گواهینامه", icon: Car },
  { id: "real-estate", label: "مالیات ملک", icon: Building },
  { id: "supplemental-insurance", label: "بیمه تکمیلی", icon: ShieldCheck },
  { id: "pension-guide", label: "بیمه بازنشستگی", icon: FileText },
  { id: "liability-insurance", label: "بیمه مسئولیت", icon: ShieldCheck },
  { id: "willhaben-security", label: "امنیت ویلهابن", icon: ShoppingBag },
  { id: "organic-markets", label: "بازارهای ارگانیک", icon: ShoppingBag },
  { id: "halal-directory", label: "مراکز حلال", icon: ShoppingBag },
  { id: "marriage-divorce", label: "ازدواج و طلاق", icon: FileText },
  { id: "tax-return", label: "اظهارنامه مالیاتی", icon: FileText },
  { id: "freelance-tax", label: "مالیات فریلنسرها", icon: FileText },
  { id: "familienbonus", label: "تخفیف مالیاتی فرزندان", icon: FileText },
  { id: "education-wifi-bfi", label: "دوره‌های WIFI و bfi", icon: GraduationCap },
  { id: "accounting-career", label: "حسابداری", icon: GraduationCap },
  { id: "klimaticket", label: "کلیما تیکت", icon: Car },
  { id: "traffic-fine-appeal", label: "اعتراض به جریمه", icon: AlertOctagon },
  { id: "rwr-calculator", label: "محاسبه امتیاز RWR", icon: Calculator },
  { id: "residency-conditions", label: "شرایط تمدید اقامت", icon: FileText },
  { id: "student-grad-guide", label: "اقامت فارغ‌التحصیلان", icon: GraduationCap },
  { id: "willhaben-furniture", label: "تجهیز خانه با Willhaben", icon: ShoppingCart },
  { id: "discounter-guide", label: "راهنمای سوپرمارکت‌ها", icon: ShoppingCart },
  { id: "obb-vorteilscard", label: "کارت تخفیف قطار", icon: Train },
  { id: "contract-cancellation", label: "فسخ قرارداد", icon: FileText },
  { id: "betriebskosten", label: "هزینه شارژ", icon: Building },
  { id: "mutter-kind-pass", label: "دفترچه مادر و کودک", icon: Smile },
  { id: "kassenarzt-directory", label: "دایرکتوری پزشکان بیمه", icon: Stethoscope },
  { id: "opera-standing-tickets", label: "بلیت‌های ایستاده اپرا", icon: Ticket },
  { id: "stadtwanderwege", label: "پیاده‌روی وین", icon: Map },
  { id: "id-austria-guide", label: "راهنمای ID Austria", icon: ShieldCheck },
  { id: "phishing-security", label: "امنیت سایبری", icon: AlertOctagon },
  { id: "tax-reg", label: "ثبت مالیاتی", icon: FileText },
  { id: "criminal-record", label: "عدم سوءپیشینه", icon: FileText },
  { id: "nostrification", label: "نوستریفیکاسیون", icon: GraduationCap },
  { id: "banks", label: "بانک و صرافی", icon: Coins },
  { id: "aml", label: "قوانین ضدپولشویی", icon: AlertOctagon },
  { id: "transport", label: "حمل‌ونقل", icon: Map },
  { id: "inspection", label: "معاینه فنی", icon: Car },
  { id: "parking", label: "پارک خودرو", icon: MapPin },
  { id: "grocery", label: "فروشگاه ایرانی", icon: ShoppingBag },
  { id: "shopping", label: "خرید و سیم‌کارت", icon: ShoppingBag },
  { id: "christmas", label: "بازارچه کریسمس", icon: Calendar },
  { id: "danube", label: "فستیوال دانوب", icon: Building },
  { id: "ski", label: "اسکی", icon: Car },
  { id: "pool", label: "استخر", icon: Building },
  { id: "theory-test", label: "آزمون رانندگی", icon: Car },
  { id: "ma35", label: "اداره MA35", icon: FileText },
  { id: "citizenship", label: "تابعیت اتریش", icon: Award },
  { id: "bank-compare", label: "مقایسه بانک‌ها", icon: Coins },
  { id: "kindergarten", label: "مهدکودک‌ها", icon: GraduationCap },
  { id: "experts", label: "کارشناسان", icon: UserCheck },
  { id: "translators", label: "مترجمان", icon: Globe },
  { id: "factcheck", label: "حقیقت‌سنجی", icon: CheckCircle },
  { id: "tracker", label: "۱. اقامت و چک‌لیست", icon: Compass },
  { id: "finance", label: "۲. امور مالی و بودجه", icon: Coins },
  { id: "mapper", label: "۳. مشاغل ونیازمندیها", icon: Map },
  { id: "german", label: "۴. زبان و آکادمی", icon: BookOpen },
  { id: "carpool", label: "۵. همسفریاب و گفتگو", icon: Users },
  { id: "trust-examples", label: "۶. نمونه اعتماد شما", icon: Sparkles },
  { id: "smart", label: "۷. سامانه‌های هوشمند", icon: Calculator },
  { id: "about", label: "درباره ما", icon: MessageSquare },
] as const;

// Lazy-loaded components for other tabs to shrink initial JS weights

const TaxCalculator = lazy(() => import("./components/TaxCalculator"));
const ResidenceTracker = lazy(() => import("./components/ResidenceTracker"));
const ServiceFinder = lazy(() => import("./components/ServiceFinder"));
const ForumDiscussion = lazy(() => import("./components/ForumDiscussion"));
const CostOfLiving = lazy(() => import("./components/CostOfLiving"));
const CommunityGallery = lazy(() => import("./components/CommunityGallery"));
const TrustExamples = lazy(() => import("./components/TrustExamples"));
const SurvivalGerman = lazy(() => import("./components/SurvivalGerman"));
const CarpoolNetworking = lazy(() => import("./components/CarpoolNetworking"));
const GoldenRules = lazy(() => import("./components/GoldenRules"));
const LocalExperienceMapper = lazy(() => import("./components/LocalExperienceMapper"));
const FinancialSmartManager = lazy(() => import("./components/FinancialSmartManager"));
const DigitalPaperworkWizard = lazy(() => import("./components/DigitalPaperworkWizard"));
const IntegrationAcademy = lazy(() => import("./components/IntegrationAcademy"));
const AustriaComprehensiveGuide = lazy(() => import("./components/AustriaComprehensiveGuide"));
const TrolutCrowdshipping = lazy(() => import("./components/TrolutCrowdshipping"));

const HealthGuide = lazy(() => import("./components/HealthGuide"));
const ImmigrationDirectory = lazy(() => import("./components/ImmigrationDirectory"));
const VafWorkAssistant = lazy(() => import("./components/VafWorkAssistant"));
const Divar = lazy(() => import("./components/Divar"));
const AboutContactNew = lazy(() => import("./components/AboutContactNew"));
const SmartSystems = lazy(() => import("./components/SmartSystems"));

const AppointmentsManager = lazy(() => import("./components/AppointmentsManager"));
const SmartHouseSearch = lazy(() => import("./components/SmartHouseSearch"));
const InitialDocumentCheck = lazy(() => import("./components/InitialDocumentCheck"));
const ServiceRatingsPortal = lazy(() => import("./components/ServiceRatingsPortal"));

// @ts-ignore
const otrishLogo = "/otrish_logo_1779961596526.png";

export default function App() {
  const [activeSegment, setActiveSegment] = useState<
    "home" | "tracker" | "finance" | "mapper" | "german" | "carpool" | "trust-examples" | "smart" | "stories" | "compare" | "glossary" | "wizard" | "compare-living" | "forms" | "schools" | "calculator" | "exchange" | "insurance" | "district" | "experts" | "translators" | "factcheck" | "nova" | "offers" | "student-finance" | "willhaben" | "neighborhood" | "volunteer" | "holidays" | "license" | "real-estate" | "supplemental" | "id-austria" | "tax-reg" | "criminal-record" | "nostrification" | "banks" | "aml" | "transport" | "inspection" | "parking" | "grocery" | "shopping" | "christmas" | "danube" | "ski" | "pool" | "theory-test" | "ma35" | "citizenship" | "bank-compare" | "kindergarten" | "supplemental-insurance" | "pension-guide" | "liability-insurance" | "willhaben-security" | "organic-markets" | "halal-directory" | "marriage-divorce" | "tax-return" | "freelance-tax" | "familienbonus" | "education-wifi-bfi" | "accounting-career" | "klimaticket" | "traffic-fine-appeal" | "rwr-calculator" | "residency-conditions" | "student-grad-guide" | "willhaben-furniture" | "discounter-guide" | "obb-vorteilscard" | "contract-cancellation" | "betriebskosten" | "mutter-kind-pass" | "kassenarzt-directory" | "emergency-dentistry" | "opera-standing-tickets" | "stadtwanderwege" | "id-austria-guide" | "phishing-security" | "about" | "immigration-assessment" | "housesearch" | "doccheck" | "ratings" | "appointment" | string
  >("home");

  const [selectedCity, setSelectedCity] = useState<string>("all");
  const [viennaTime, setViennaTime] = useState<string>("");
  const [viennaGreeting, setViennaGreeting] = useState<string>("خوش آمدید 🇦🇹");
  const [sparkleActive, setSparkleActive] = useState<boolean>(false);
  const [sparkleCount, setSparkleCount] = useState<number>(0);

  // States for live page customization/updates as shown on user's button image
  const [isFooterOptimized, setIsFooterOptimized] = useState<boolean>(true);
  const [showIntroBanner, setShowIntroBanner] = useState<boolean>(true);
  const [isHeaderFooterUpdated, setIsHeaderFooterUpdated] = useState<boolean>(true);
  const [optimizationToast, setOptimizationToast] = useState<string | null>(null);

  // States for live Austrian news integration
  const [austriaNews, setAustriaNews] = useState<any[]>([]);
  const [newsLastUpdated, setNewsLastUpdated] = useState<string>("");
  const [newsSourceText, setNewsSourceText] = useState<string>("");
  const [isNewsLoading, setIsNewsLoading] = useState<boolean>(false);
  const [selectedArticle, setSelectedArticle] = useState<any>(null);
  const [isNewsModalOpen, setIsNewsModalOpen] = useState<boolean>(false);
  const [isForcingNewsRefresh, setIsForcingNewsRefresh] = useState<boolean>(false);

  // Dynamic High-Fidelity SEO state
  const [seoState, setSeoState] = useState<{
    title: string;
    description: string;
    keywords: string;
    schema: any[];
  }>({
    title: "اتریش‌نشین | همیار همه‌جانبه فارسی‌زبانان مقیم اتریش 🇦🇹",
    description: "اتریش‌نشین؛ همیار همه‌جانبه فارسی‌زبانان مقیم اتریش. پورتال مستقل جهت پایش MA35، محاسبه حقوق و پایش نرخ زنده ارز.",
    keywords: "اتریش, فارسی زبانان اتریش, ایرانیان اتریش, قیمت ارز زنده, محاسبه حقوق اتریش, پایش MA35, یادگیری آلمانی, همسفریاب وین",
    schema: []
  });

  const fetchAustriaNewsList = async (force: boolean = false) => {
    if (force) {
      setIsForcingNewsRefresh(true);
    } else {
      setIsNewsLoading(true);
    }
    
    const CLIENT_FALLBACK_NEWS = [
      {
        title: "تمدید خودکار کارت‌های بیمه سلامت در سراسر اتریش",
        summary: "سازمان بیمه سلامت ملی اتریش (ÖGK) اعلام کرد مهلت اعتبار کارت‌های ملکی عکس‌دار الکترونیکی منقضی شده را تا دسامبر ۲۰۲۶ تمدید کتبی کرده است تا نیاز به تعویض حضوری نباشد.",
        category: "بهداشت و سلامت 🏥",
        date: "امروز",
        source: "ÖGK فدرال"
      },
      {
        title: "اصلاح شروط کارت سرخ-سفید-سرخ و کاهش حداقل حقوق دریافتی",
        summary: "بر اساس دستورالعمل جدید وزارت کار اتریش، برای سهولت ورود فارغ‌التحصیلان خارجی دانشگاه‌های اتریش به بازار کار، شرط درآمد ناخالص ماهانه جهت تمدید و دریافت اقامت کاهش یافته است.",
        category: "مهاجرت و قوانین 💼",
        date: "امروز",
        source: "وزارت کار فدرال اتریش"
      },
      {
        title: "تسهیل ثبت هویت دیجیتال و راه‌اندازی سامانه یکپارچه ID Austria",
        summary: "ادارات ثبت احوال اتریش از تسهیل ثبت‌نام برای اتباع خارجی و مقیمان غیرمقیم جهت دسترسی به سامانه‌های مالیاتی فینانس آنلاین خبر دادند.",
        category: "هویت دیجیتال 🔐",
        date: "امروز",
        source: "وزارت مسکن و اقتصاد"
      }
    ];

    setAustriaNews(CLIENT_FALLBACK_NEWS);
    setNewsLastUpdated(new Date().toLocaleTimeString("fa-IR"));
    setIsNewsLoading(false);
    setIsForcingNewsRefresh(false);
  };

  const [isSearchModalOpen, setIsSearchModalOpen] = useState<boolean>(false);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState<boolean>(false);

  // Global Keyboard Shortcut: Ctrl+K / Cmd+K opens SuperApp Search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setIsSearchModalOpen((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Sync URL query params with activeSegment for independent shareable subpages
  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const seg = params.get("segment");
      if (seg && seg !== activeSegment) {
        setActiveSegment(seg);
      }
    }
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const url = new URL(window.location.href);
      if (activeSegment === "home") {
        url.searchParams.delete("segment");
      } else {
        url.searchParams.set("segment", activeSegment);
      }
      window.history.replaceState(null, "", url.toString());
    }
  }, [activeSegment]);
  useEffect(() => {
    const defaultTitle = "اتریش‌نشین | همیار همه‌جانبه فارسی‌زبانان مقیم اتریش 🇦🇹";
    let title = defaultTitle;
    let description = "اتریش‌نشین؛ همیار همه‌جانبه فارسی‌زبانان مقیم اتریش. پورتال مستقل جهت پایش MA35، محاسبه حقوق و پایش نرخ زنده ارز.";
    let keywords = "اتریش, فارسی زبانان اتریش, ایرانیان اتریش, قیمت ارز زنده, محاسبه حقوق اتریش, پایش MA35, یادگیری آلمانی, همسفریاب وین";
    let breadcrumbName = "صفحه اصلی پورتال";

    switch (activeSegment) {
      case "home":
        title = "اتریش‌نشین | پورتال هوشمند و همیار مستقل فارسی‌زبانان اتریش 🇦🇹";
        description = "خانه رسمی اتریش‌نشین: کانون مستقل همیاری داوطلبانه، اطلاعات وقت‌های سفارت، اخبار اداری، راهنمای ملده و معادل‌سازی مدرک.";
        keywords = "اتریش‌نشین, مهاجرت اتریش, ملده وین, کانون ایرانیان وین,ÖGK بیمه, اقامت اتریش";
        breadcrumbName = "صفحه اصلی پورتال";
        break;
      case "tracker":
        title = "پایش اقامت، چک‌لیست و وقت‌های اداری MA35 | اتریش‌نشین";
        description = "برنامه‌ریزی، پیگیری و پایش آنلاین نوبت‌های اداره اقامت MA35 اتریش، مدارک الحاق خانواده، و الزامات کارت سرخ-سفید-سرخ.";
        keywords = "پایش MA35, وقت سفارت اتریش, اقامت دانشجویی اتریش, کارت قرمز سفید قرمز, فرم ملده";
        breadcrumbName = "پیگیری اقامت و نوبت‌های MA35";
        break;
      case "finance":
        title = "محاسبه حقوق Brutto-Netto و قیمت زنده بازار آزاد ارز | اتریش‌نشین";
        description = "ماشین حساب پیشرفته مالیات و حقوق اتریش (خالص به ناخالص AMS) به انضمام قیمت زنده ارز لحظه‌ای یورو و دلار بازار آزاد.";
        keywords = "محاسبه حقوق اتریش, Brutto Netto, مالیات اتریش, قیمت ارز زنده, قیمت زنده یورو, تبدیل ریال تومان";
        breadcrumbName = "امور مالی و پایش زنده ارز";
        break;
      case "mapper":
        title = "دایرکتوری پزشکان فارسی‌زبان، مشاغل ونیازمندیها اتریش | اتریش‌نشین";
        description = "راهنمای شهری پیدا کردن برترین پزشکان متخصص طرف قرارداد ÖGK، وکلا، صرافی‌ها، فلومارکت‌ها و کسب‌وکارهای ایرانیان در وین و سراسر ایالت‌ها.";
        keywords = "پزشک فارسی زبان وین, مشاغل ایرانی اتریش, وکیل ایرانی وین, فلومارکت اتریش, دندانپزشک ایرانی اتریش";
        breadcrumbName = "نقشه مشاغل و دایرکتوری پزشکان";
        break;
      case "german":
        title = "آموزش زبان آلمانی، واژگان بومی و آکادمی بقا | اتریش‌نشین";
        description = "یادگیری رایگان و خودآموز اصطلاحات اداری زبان آلمانی اتریشی (Survival German)، فرم‌ساز هوشمند ملده و راهنمای ادغام فرهنگ آلپ.";
        keywords = "آلمانی اتریشی, واژگان ملده, اصطلاحات AMS, مکالمات روزمره آلمانی, آزمون ÖIF";
        breadcrumbName = "آکادمی زبان آلمانی بومی";
        break;
      case "carpool":
        title = "همسفریاب فرودگاه وین، تالار گفتگو و وسایل دست دوم | اتریش‌نشین";
        description = "شبکه اشتراکی سفرها و حمل چمدان تهران-وین، گفتگو در مورد چالش‌های زندگی در اتریش، کلوپ فتبال و ثبت آگهی‌های دست دوم هموطنان.";
        keywords = "همسفر فرودگاه وین, حمل چمدان اتریش, دیوار ایرانیان اتریش, تالار گفتگو اتریش";
        breadcrumbName = "همسفریاب و دیوار اتریش";
        break;
      case "gallery":
        title = "قاب زیبای اتریش و پیوند تاریخی | اتریش‌نشین";
        description = "گالری دیدنی‌های وین، زالتسبورگ و شهرهای کوهستانی، و رویدادهای فرهنگی ایرانیان اتریش.";
        keywords = "تصاویر اتریش, گردشگری وین, رویدادهای ایرانیان وین";
        breadcrumbName = "تصاویر اتریش";
        break;
      case "about":
        title = "درباره ما، تایید صلاحیت کانون و تماس مستقیم کانون | اتریش‌نشین";
        description = "اطلاعات شفاف درباره اهداف مستقل، ایمیل‌های تماس رسمی info@otrish-iran.ir، دفتر نمایندگی وین و تاییدیه اعتماد و قوانین GDPR.";
        keywords = "تماس با اتریش‌نشین, ایمیل اتریش‌نشین, دفتر وین, قوانین GDPR اتریش";
        breadcrumbName = "درباره ما و تماس با کانون";
        break;
      case "smart":
        title = "سامانه‌های هوشمند و ابزارهای ارزیابی مهاجرتی اتریش | اتریش‌نشین";
        description = "مجموعه ابزارهای هوشمند محاسباتی پایش کارت سرخ-سفید-سرخ، تمکن مالی ماهانه ASVG سال ۲۰۲۶، معادل‌سازی مدرک Nostrifizierung و شبیه‌ساز مصاحبه سفارت.";
        keywords = "سامانه هوشمند اتریش, ارزیابی کارت سرخ سفید سرخ, تمکن مالی اتریش ۲۰۲۶, معادل سازی مدرک, مصاحبه سفارت اتریش";
        breadcrumbName = "سامانه‌های هوشمند ارزیابی";
        break;
    }

    // Set Document title
    document.title = title;

    // Set Meta Tags dynamically for robust fallback
    const updateMetaTag = (name: string, content: string, property: boolean = false) => {
      const attr = property ? "property" : "name";
      let el = document.querySelector(`meta[${attr}="${name}"]`);
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };

    updateMetaTag("description", description);
    updateMetaTag("keywords", keywords);
    
    // OG OpenGraph Tags
    updateMetaTag("og:title", title, true);
    updateMetaTag("og:description", description, true);
    updateMetaTag("og:url", `https://otrish-iran.ir/?segment=${activeSegment}`, true);
    
    // Twitter Card
    updateMetaTag("twitter:title", title);
    updateMetaTag("twitter:description", description);

    // Dynamic Sitemaps & Search Engines Crawl verification
    updateMetaTag("robots", "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1");

    // Dynamic Script LD+JSON Schema Structured Data Injection
    const schemaId = "seo-jsonld-structured-data";
    let scriptEl = document.getElementById(schemaId) as HTMLScriptElement | null;
    if (!scriptEl) {
      scriptEl = document.createElement("script");
      scriptEl.id = schemaId;
      scriptEl.type = "application/ld+json";
      document.head.appendChild(scriptEl);
    }

    const breadcrumbsJson = {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "name": "راهنمای ناوبری اتریش‌نشین",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "اتریش‌نشین",
          "item": "https://otrish-iran.ir/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": breadcrumbName,
          "item": `https://otrish-iran.ir/?segment=${activeSegment}`
        }
      ]
    };

    const websiteJson = {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "اتریش‌نشین | Otrish-Iran",
      "alternateName": "Otrish Neshin Portal",
      "url": "https://otrish-iran.ir/",
      "potentialAction": {
        "@type": "SearchAction",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://otrish-iran.ir/?search={search_term_string}"
        },
        "query-input": "required name=search_term_string"
      }
    };

    const organizationJson = {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "اتریش‌نشین",
      "url": "https://otrish-iran.ir/",
      "logo": "https://otrish-iran.ir/otrish_logo_1779961596526.png",
      "contactPoint": {
        "@type": "ContactPoint",
        "email": "info@otrish-iran.ir",
        "contactType": "customer service",
        "areaServed": "AT",
        "availableLanguage": ["Persian", "German"]
      }
    };

    // Upgraded high-fidelity Service Schema markup based on segment
    let serviceJson: any = null;
    switch (activeSegment) {
      case "tracker":
        serviceJson = {
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "پایش اقامت، چک‌لیست و وقت‌های اداری MA35",
          "provider": {
            "@type": "Organization",
            "name": "اتریش‌نشین",
            "url": "https://otrish-iran.ir/"
          },
          "serviceType": "Immigration & Residency Tracking",
          "description": "پایش آنلاین نوبت‌های اداره اقامت MA35 اتریش، مدارک الحاق خانواده و محاسبات کارت سرخ-سفید-سرخ"
        };
        break;
      case "finance":
        serviceJson = {
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "محاسبه حقوق Brutto-Netto و پایش زنده ارز",
          "provider": {
            "@type": "Organization",
            "name": "اتریش‌نشین",
            "url": "https://otrish-iran.ir/"
          },
          "serviceType": "Financial Advisory Tools",
          "description": "ماشین حساب حقوق خالص و ناخالص اتریش به همراه پایش قیمت ارز آزاد یورو و دلار"
        };
        break;
      case "mapper":
        serviceJson = {
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "دایرکتوری پزشکان فارسی‌زبان و دایرکتوری مشاغل اتریش",
          "provider": {
            "@type": "Organization",
            "name": "اتریش‌نشین",
            "url": "https://otrish-iran.ir/"
          },
          "serviceType": "Community Directory & Maps",
          "description": "جستجوی پزشکان متخصص هم‌زبان در اتریش و کسب‌وکارهای ایرانیان مقیم اتریش"
        };
        break;
      case "german":
        serviceJson = {
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "آموزش زبان آلمانی اتریشی و آکادمی بقا",
          "provider": {
            "@type": "Organization",
            "name": "اتریش‌نشین",
            "url": "https://otrish-iran.ir/"
          },
          "serviceType": "Language Learning Portal",
          "description": "آموزش اصطلاحات اداری، فرم‌سازها و راهنماهای همگون‌سازی فرهنگی اتریش"
        };
        break;
      case "carpool":
        serviceJson = {
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "همسفریاب فرودگاه وین و دیوار دست دوم اتریش",
          "provider": {
            "@type": "Organization",
            "name": "اتریش‌نشین",
            "url": "https://otrish-iran.ir/"
          },
          "serviceType": "Community Exchange",
          "description": "شبکه همسفریابی فرودگاه، تالار گفتگوی مهاجرین و نیازمندیهای دست دوم"
        };
        break;
      case "smart":
        serviceJson = {
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "سامانه‌های هوشمند محاسباتی اتریش",
          "provider": {
            "@type": "Organization",
            "name": "اتریش‌نشین",
            "url": "https://otrish-iran.ir/"
          },
          "serviceType": "Smart Assessment Calculators",
          "description": "سامانه‌های هوشمند شبیه‌ساز امتیاز کارت سرخ-سفید-سرخ، تمکن مالی و معادل‌سازی مدرک"
        };
        break;
    }

    const graphElements: any[] = [breadcrumbsJson, websiteJson, organizationJson];
    if (serviceJson) {
      graphElements.push(serviceJson);
    }

    // Combine into a multi-graph layout for search engines and AI parsers to citation check
    const multiSchema = {
      "@context": "https://schema.org",
      "@graph": graphElements
    };

    scriptEl.textContent = JSON.stringify(multiSchema);

    // Update state to render in Helmet dynamically
    setSeoState({
      title,
      description,
      keywords,
      schema: [multiSchema]
    });
  }, [activeSegment]);

  const showOptimizationToast = (message: string) => {
    toast.success(message);
  };

  useEffect(() => {
    const updateTimeAndGreeting = () => {
      try {
        const d = new Date();
        
        // Vienna Timezone representation
        const options: Intl.DateTimeFormatOptions = {
          timeZone: "Europe/Vienna",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: false
        };
        const formatter = new Intl.DateTimeFormat("fa-IR", options);
        setViennaTime(formatter.format(d));

        // Determine hour in Vienna for the tailored Persian greeting
        const viennaHourStr = new Intl.DateTimeFormat("en-US", {
          timeZone: "Europe/Vienna",
          hour: "numeric",
          hour12: false
        }).format(d);
        const viennaHour = parseInt(viennaHourStr, 10);

        if (viennaHour >= 5 && viennaHour < 12) {
          setViennaGreeting("صبح آلپی شما بخیر 🌄");
        } else if (viennaHour >= 12 && viennaHour < 17) {
          setViennaGreeting("روز زیبای اتریشی شما بخیر ☀️");
        } else if (viennaHour >= 17 && viennaHour < 21) {
          setViennaGreeting("عصر آرام اتریشی بخیر 🍷");
        } else {
          setViennaGreeting("شب رویایی دنج در دل آلپ بخیر 🌌");
        }
      } catch (e) {
        setViennaTime(new Date().toLocaleTimeString("fa-IR"));
        setViennaGreeting("خوش آمدید 🇦🇹");
      }
    };

    updateTimeAndGreeting();
    const interval = setInterval(updateTimeAndGreeting, 1000);
    return () => clearInterval(interval);
  }, []);

  const triggerSparkleFest = () => {
    setSparkleActive(true);
    setSparkleCount(prev => prev + 1);
    setTimeout(() => setSparkleActive(false), 800);
  };

  return (
    <>
      <SEO 
        title={seoState.title}
        description={seoState.description}
        keywords={seoState.keywords}
        schemaData={seoState.schema}
      />
      <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col justify-between font-sans selection:bg-red-200" dir="rtl">
        {/* First-time Welcome & Country Locator Popup */}
        <WelcomeNotification />

      {/* Top Decorative Flag Bar (Austrian Flag Styling) */}
      <div className="h-1.5 w-full bg-gradient-to-r from-red-650 via-white to-red-650 bg-red-600 block"></div>

      {/* Sticky Top Live News Ticker — ONLY element that remains fixed at top during scrolling! */}
      <div className="sticky top-0 z-40 w-full bg-stone-950/95 backdrop-blur-md shadow-md border-b border-stone-800">
        <div className="max-w-7xl mx-auto px-2.5 sm:px-4 md:px-6 py-1.5 sm:py-2">
          <LiveNewsTicker
            austriaNews={austriaNews}
            isNewsLoading={isNewsLoading}
            onOpenNews={() => {
              setIsNewsModalOpen(true);
              trackEvent("open_news_hub_modal", "interaction", { count: austriaNews.length });
            }}
            onOpenMobileMenu={() => setIsMobileNavOpen(true)}
          />
        </div>
      </div>

      {/* Main Container */}
      <div className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-4 sm:py-6 space-y-6 sm:space-y-8 flex-1">

        {/* Super App Unified Header (Austrian National Aesthetic, Vienna Clock, Quick Search & Responsive Controls) */}
        <SuperAppHeader
          activeSegment={activeSegment}
          onSelectSegment={(segment) => {
            setActiveSegment(segment);
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
          onOpenSearch={() => setIsSearchModalOpen(true)}
          onOpenNews={() => {
            setIsNewsModalOpen(true);
            trackEvent("open_news_hub_modal", "interaction", { count: austriaNews.length });
          }}
          onOpenMobileMenu={() => setIsMobileNavOpen(true)}
          viennaTime={viennaTime}
          viennaGreeting={viennaGreeting}
          sparkleActive={sparkleActive}
          triggerSparkleFest={triggerSparkleFest}
          austriaNews={austriaNews}
          isNewsLoading={isNewsLoading}
        />

        {/* Segment Content Rendering Wrapper with dynamic Suspense Loading fallback */}
        <main className="space-y-8 min-h-[400px]">
          <Suspense fallback={
            <div className="flex flex-col items-center justify-center p-12 bg-white rounded-3xl border border-stone-200 shadow-sm min-h-[350px] text-center font-sans space-y-4 animate-pulse">
              <div className="w-10 h-10 border-4 border-red-650 border-t-transparent rounded-full animate-spin"></div>
              <div className="space-y-1">
                <p className="text-stone-800 font-black text-[13px]">در حال آماده‌سازی و بارگذاری بخش مربوطه...</p>
                <p className="text-stone-400 font-medium text-[11px] font-mono">Loading dynamic module... Please wait 🇦🇹</p>
              </div>
            </div>
          }>
            <AnimatePresence mode="wait">
              <motion.div
                key={activeSegment}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25, ease: "easeInOut" }}
                className="space-y-8"
              >
                {/* SEGMENT 0: HOME PORTAL MAIN DASHBOARD */}
                {activeSegment === "home" ? (
                  <div className="space-y-12 text-right">
                    <SuperAppLauncher
                      onSelectPage={(seg) => {
                        setActiveSegment(seg);
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }}
                      onOpenSearch={() => setIsSearchModalOpen(true)}
                    />
                    <AustriaIranNewsBanner />
                    <AustriaMainDashboard onNavigate={(seg) => setActiveSegment(seg)} setSelectedCity={setSelectedCity} />
                    <EcosystemPortal />
                  </div>
                ) : (
                  <SuperAppPageLayout
                    pageId={activeSegment}
                    onNavigate={(seg) => {
                      setActiveSegment(seg);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                  >
                    {/* SEGMENT 1: RESIDENCE ADVISOR & ADV TOOLS */}
                {activeSegment === "tracker" && (
                  <div className="space-y-8 text-right">
                    <ResidenceTracker />
                    <ImmigrationDirectory onNavigate={(seg) => setActiveSegment(seg)} />
                    <VafWorkAssistant />
                    <LocalExperienceMapper />
                  </div>
                )}

                {/* SEGMENT 2: GROCERIES, TAXES & CURRENCY CALCULATORS */}
                {activeSegment === "finance" && (
                  <div className="space-y-8 text-right">
                    <CostOfLiving />
                    <BruttoNettoCalculator />
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 font-sans">
                      <TaxCalculator />
                    </div>
                    <FinancialSmartManager />
                  </div>
                )}

                {/* SEGMENT 3: DETAILED BUSINESS MAPPER & OUTLET FLOMARKETS */}
                {activeSegment === "mapper" && (
                  <div className="space-y-8 text-right">
                    <ServiceFinder selectedCity={selectedCity} setSelectedCity={setSelectedCity} />
                    <LocalExperienceMapper />
                  </div>
                )}

                {/* SEGMENT 4: DEUTSCHE ALPIN STUDY & COOPERATIVE RULES */}
                {activeSegment === "german" && (
                  <div className="space-y-8 text-right">
                    <SurvivalGerman />
                    <InterpreterAcademy />
                    <IntegrationAcademy />
                    <GoldenRules />
                    <DigitalPaperworkWizard />
                  </div>
                )}

                {/* SEGMENT 5: AIRPORT CARPOOLS, LUGGAGES & HOOD TALKFORUM */}
                {activeSegment === "carpool" && (
                  <div className="space-y-8 text-right">
                    <CarpoolNetworking />
                    <TrolutCrowdshipping />
                    <ForumDiscussion />
                    <AustriaClassifiedsBlock />
                    <Divar />
                  </div>
                )}

                {/* SEGMENT 6: TRUST EXAMPLES */}
                {activeSegment === "trust-examples" && (
                  <div className="space-y-8 text-right">
                    <TrustExamples onNavigate={(segment) => setActiveSegment(segment as any)} />
                  </div>
                )}

                {/* SEGMENT 7: SMART SYSTEMS EVALUATION PORTAL */}
                {activeSegment === "smart" && (
                  <div className="space-y-8 text-right">
                    <SmartSystems />
                    <WohnbeihilfeBlock />
                  </div>
                )}
                {/* SEGMENT 9: ABOUT & CONTACT TRUST AND VERIFICATION HUB */}
                {activeSegment === "about" && (
                  <div className="space-y-8 text-right">
                    <AboutContactNew />
                  </div>
                )}
                {activeSegment === "immigration-assessment" && (
                  <div className="space-y-8 text-right">
                    <ImmigrationAssessment />
                  </div>
                )}
                
                {activeSegment === "stories" && (
                  <div className="space-y-8 text-right">
                    <ExperienceGallery />
                  </div>
                )}
                {activeSegment === "compare" && (
                  <div className="space-y-8 text-right">
                    <ComparisonWizard onSelectSegment={setActiveSegment} />
                  </div>
                )}
                {activeSegment === "glossary" && (
                  <div className="space-y-8 text-right">
                    <AdministrativeGlossary />
                  </div>
                )}
                {activeSegment === "wizard" && (
                  <div className="space-y-8 text-right">
                    <VisaSuitabilityWizard />
                  </div>
                )}
                {activeSegment === "compare-living" && (
                  <div className="space-y-8 text-right">
                    <CostOfLivingComparison />
                  </div>
                )}
                {activeSegment === "forms" && (
                  <div className="space-y-8 text-right">
                    <FormDownloadLibrary />
                  </div>
                )}
                {activeSegment === "schools" && (
                  <div className="space-y-8 text-right">
                    <SchoolDirectory />
                  </div>
                )}
                {activeSegment === "calculator" && (
                  <div className="space-y-8 text-right">
                    <VisaCalculator />
                  </div>
                )}
                {activeSegment === "exchange" && (
                  <div className="space-y-8 text-right">
                    <ExchangeRateWidget />
                  </div>
                )}
                {activeSegment === "insurance" && (
                  <div className="space-y-8 text-right">
                    <InsuranceFilterDirectory />
                  </div>
                )}
                {activeSegment === "district" && (
                  <div className="space-y-8 text-right">
                    <DistrictGuide />
                  </div>
                )}
                {activeSegment === "experts" && (
                  <div className="space-y-8 text-right">
                    <ExpertProfile />
                  </div>
                )}
                {activeSegment === "translators" && (
                  <div className="space-y-8 text-right">
                    <TranslatorDirectory />
                  </div>
                )}
                {activeSegment === "factcheck" && (
                  <div className="space-y-8 text-right">
                    <FactCheckArticles />
                  </div>
                )}
                {activeSegment === "nova" && (
                  <div className="space-y-8 text-right">
                    <NoVACalculator />
                  </div>
                )}
                {activeSegment === "offers" && (
                  <div className="space-y-8 text-right">
                    <OfferDirectory />
                  </div>
                )}
                {activeSegment === "student-finance" && (
                  <div className="space-y-8 text-right">
                    <StudentFinanceCalculator />
                  </div>
                )}
                {activeSegment === "willhaben" && (
                  <div className="space-y-8 text-right">
                    <WillhabenGuide />
                  </div>
                )}
                {activeSegment === "neighborhood" && (
                  <div className="space-y-8 text-right">
                    <NeighborhoodComparison />
                  </div>
                )}
                {activeSegment === "volunteer" && (
                  <div className="space-y-8 text-right">
                    <VolunteerDirectory />
                  </div>
                )}
                {activeSegment === "holidays" && (
                  <div className="space-y-8 text-right">
                    <PublicHolidayCalendar />
                  </div>
                )}
                {activeSegment === "license" && (
                  <div className="space-y-8 text-right">
                    <DrivingLicenseGuide />
                  </div>
                )}
                {activeSegment === "real-estate" && (
                  <div className="space-y-8 text-right">
                    <RealEstateTaxCalculator />
                  </div>
                )}
                {activeSegment === "supplemental" && (
                  <div className="space-y-8 text-right">
                    <InsuranceSupplementalGuide />
                  </div>
                )}
                {activeSegment === "id-austria" && (
                  <div className="space-y-8 text-right">
                    <IdAustriaGuide />
                  </div>
                )}
                {activeSegment === "tax-reg" && (
                  <div className="space-y-8 text-right">
                    <TaxRegistrationGuide />
                  </div>
                )}
                {activeSegment === "criminal-record" && (
                  <div className="space-y-8 text-right">
                    <CriminalRecordGuide />
                  </div>
                )}
                {activeSegment === "nostrification" && (
                  <div className="space-y-8 text-right">
                    <NostrificationGuide />
                  </div>
                )}
                {activeSegment === "banks" && (
                  <div className="space-y-8 text-right">
                    <BankExchangeDirectory />
                  </div>
                )}
                {activeSegment === "aml" && (
                  <div className="space-y-8 text-right">
                    <MoneyLaunderingInfo />
                  </div>
                )}
                {activeSegment === "transport" && (
                  <div className="space-y-8 text-right">
                    <PublicTransportGuide />
                  </div>
                )}
                {activeSegment === "inspection" && (
                  <div className="space-y-8 text-right">
                    <VehicleInspectionGuide />
                  </div>
                )}
                {activeSegment === "parking" && (
                  <div className="space-y-8 text-right">
                    <ParkingGuide />
                  </div>
                )}
                {activeSegment === "grocery" && (
                  <div className="space-y-8 text-right">
                    <GroceryDirectory />
                  </div>
                )}
                {activeSegment === "shopping" && (
                  <div className="space-y-8 text-right">
                    <ShoppingGuide />
                  </div>
                )}
                {activeSegment === "christmas" && (
                  <div className="space-y-8 text-right">
                    <ChristmasMarketGuide />
                  </div>
                )}
                {activeSegment === "danube" && (
                  <div className="space-y-8 text-right">
                    <DanubeFestivalGuide />
                  </div>
                )}
                {activeSegment === "ski" && (
                  <div className="space-y-8 text-right">
                    <SkiResortGuide />
                  </div>
                )}
                {activeSegment === "pool" && (
                  <div className="space-y-8 text-right">
                    <PoolTicketGuide />
                  </div>
                )}
                {activeSegment === "theory-test" && (
                  <div className="space-y-8 text-right">
                    <TheoryExamTest />
                  </div>
                )}
                {(activeSegment === "ma35" || activeSegment === "appointment") && (
                  <div className="space-y-8 text-right">
                    <AppointmentsManager />
                  </div>
                )}
                {activeSegment === "citizenship" && (
                  <div className="space-y-8 text-right">
                    <CitizenshipGuide />
                  </div>
                )}
                {activeSegment === "bank-compare" && (
                  <div className="space-y-8 text-right">
                    <BankComparisonGuide />
                  </div>
                )}
                {activeSegment === "kindergarten" && (
                  <div className="space-y-8 text-right">
                    <KindergartenGuide />
                  </div>
                )}
                {activeSegment === "supplemental-insurance" && (
                  <div className="space-y-8 text-right">
                    <SupplementalInsuranceGuide />
                  </div>
                )}
                {activeSegment === "pension-guide" && (
                  <div className="space-y-8 text-right">
                    <PensionGuide />
                  </div>
                )}
                {activeSegment === "liability-insurance" && (
                  <div className="space-y-8 text-right">
                    <LiabilityInsuranceGuide />
                  </div>
                )}
                {activeSegment === "willhaben-security" && (
                  <div className="space-y-8 text-right">
                    <WillhabenSecurityGuide />
                  </div>
                )}
                {activeSegment === "organic-markets" && (
                  <div className="space-y-8 text-right">
                    <OrganicMarketsGuide />
                  </div>
                )}
                {activeSegment === "halal-directory" && (
                  <div className="space-y-8 text-right">
                    <HalalDirectory />
                  </div>
                )}
                {activeSegment === "marriage-divorce" && (
                  <div className="space-y-8 text-right">
                    <MarriageDivorceGuide />
                  </div>
                )}
                {activeSegment === "tax-return" && (
                  <div className="space-y-8 text-right">
                    <TaxReturnGuide />
                  </div>
                )}
                {activeSegment === "freelance-tax" && (
                  <div className="space-y-8 text-right">
                    <FreelanceTaxHub />
                  </div>
                )}
                {activeSegment === "familienbonus" && (
                  <div className="space-y-8 text-right">
                    <FamilienbonusGuide />
                  </div>
                )}
                {activeSegment === "education-wifi-bfi" && (
                  <div className="space-y-8 text-right">
                    <WifiBfiGuide />
                  </div>
                )}
                {activeSegment === "accounting-career" && (
                  <div className="space-y-8 text-right">
                    <AccountingCareerGuide />
                  </div>
                )}
                {activeSegment === "klimaticket" && (
                  <div className="space-y-8 text-right">
                    <KlimaTicketGuide />
                  </div>
                )}
                {activeSegment === "traffic-fine-appeal" && (
                  <div className="space-y-8 text-right">
                    <TrafficFineAppealGuide />
                  </div>
                )}
                {activeSegment === "rwr-calculator" && (
                  <div className="space-y-8 text-right">
                    <RWRPunterRechner />
                  </div>
                )}
                {activeSegment === "residency-conditions" && (
                  <div className="space-y-8 text-right">
                    <ResidencyConditionGuide />
                  </div>
                )}
                {activeSegment === "student-grad-guide" && (
                  <div className="space-y-8 text-right">
                    <StudentGradRelocationGuide />
                  </div>
                )}
                {activeSegment === "willhaben-furniture" && (
                  <div className="space-y-8 text-right">
                    <WillhabenFurnitureGuide />
                  </div>
                )}
                {activeSegment === "discounter-guide" && (
                  <div className="space-y-8 text-right">
                    <DiscounterGuide />
                  </div>
                )}
                {activeSegment === "obb-vorteilscard" && (
                  <div className="space-y-8 text-right">
                    <ObbVorteilscardGuide />
                  </div>
                )}
                {activeSegment === "contract-cancellation" && (
                  <div className="space-y-8 text-right">
                    <ContractCancellationGuide />
                  </div>
                )}
                {activeSegment === "housesearch" && (
                  <div className="space-y-8 text-right">
                    <SmartHouseSearch />
                  </div>
                )}
                {activeSegment === "doccheck" && (
                  <div className="space-y-8 text-right">
                    <InitialDocumentCheck />
                  </div>
                )}
                {activeSegment === "ratings" && (
                  <div className="space-y-8 text-right">
                    <ServiceRatingsPortal />
                  </div>
                )}
                {activeSegment === "betriebskosten" && (
                  <div className="space-y-8 text-right">
                    <BetriebskostenGuide />
                  </div>
                )}
                {activeSegment === "mutter-kind-pass" && (
                  <div className="space-y-8 text-right">
                    <MutterKindPassGuide />
                  </div>
                )}
                {activeSegment === "kassenarzt-directory" && (
                  <div className="space-y-8 text-right">
                    <KassenarztDirectory />
                  </div>
                )}
                {activeSegment === "opera-standing-tickets" && (
                  <div className="space-y-8 text-right">
                    <OperaStandingTicketGuide />
                  </div>
                )}
                {activeSegment === "stadtwanderwege" && (
                  <div className="space-y-8 text-right">
                    <StadtwanderwegeGuide />
                  </div>
                )}
                {activeSegment === "id-austria-guide" && (
                  <div className="space-y-8 text-right">
                    <IdAustriaActivationGuide />
                  </div>
                )}
                {activeSegment === "phishing-security" && (
                  <div className="space-y-8 text-right">
                    <PhishingSecurityGuide />
                  </div>
                )}
                  </SuperAppPageLayout>
                )}
              </motion.div>
            </AnimatePresence>
          </Suspense>
        </main>

        {/* Friendly Advisory Alert Block */}
        <section className="bg-rose-50 border border-stone-200 rounded-2xl p-5 flex items-start gap-4 text-right">
          <AlertOctagon className="w-6 h-6 text-red-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h5 className="font-extrabold text-stone-900 text-xs sm:text-sm">سلب مسئولیت رسمی و حقوقی همراهان:</h5>
            <p className="text-[11px] text-stone-500 font-bold leading-relaxed">
              تمامی ابزارها و خدمات ارائه شده در این پورتال—اعم از شبیهسازهای مالیاتی، سامانههای پایش وقتهای اداری شهرداریها و راهنماهای معادلسازی مدارک—صرفاً با هدف اطلاعرسانی، راهنمایی اولیه و همیاری داوطلبانه با هموطنان عزیز طراحی شده است. این اطلاعات به هیچعنوان جایگزین قوانین رسمی، کارشناسی حقوقی یا مشاوره اداری تخصصی نمیباشد. متقاضیان موظفند جهت اقدام نهایی و قطعی، مدارک و شرایط خود را مستقیماً از طریق مراجع ذیصلاح قانونی استعلام و تطدیق دهند. این پورتال هیچگونه مسئولیت حقوقی در قبال تصمیمات اتخاذ شده بر اساس این دادهها بر عهده نمیگیرد.
            </p>
          </div>
        </section>
      </div>

      {/* EXTREMELY HIGH-FIDELITY ENGAGING COMMUNITY FOOTER ZONE & RECRUITER */}
      <footer className={`transition-all duration-500 border-t mt-16 w-full relative overflow-hidden text-right ${
        isHeaderFooterUpdated 
          ? "bg-gradient-to-br from-[#0a1128] via-[#001f54] to-[#0a1128] border-blue-900/40 text-stone-200 py-6 px-6 md:px-12 shadow-[0_-12px_40px_rgba(23,39,181,0.2)]" 
          : "bg-gradient-to-br from-[#0c1b40] to-[#040a1c] border-blue-950/80 text-stone-350 py-6 px-6 md:px-12"
      }`}>
        {/* Ambient glowing fields */}
        <div className="absolute bottom-0 right-10 w-80 h-80 rounded-full bg-[#1727b5]/10 blur-[120px] pointer-events-none"></div>
        <div className="absolute top-0 left-10 w-64 h-64 rounded-full bg-blue-500/10 blur-[100px] pointer-events-none"></div>

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-10 pb-4">
          
          {/* Column 1: App Info & Mission Statement */}
          <div className="lg:col-span-7 space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-stone-900 border border-blue-500/40 rounded-full p-0.5 flex items-center justify-center shadow-lg transform rotate-[-6deg] hover:rotate-[6deg] transition-transform">
                <img 
                  src={otrishLogo} 
                  alt="Otrishneshin Logo" 
                  referrerPolicy="no-referrer"
                  width="40"
                  height="40"
                  loading="lazy"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <div>
                <h4 className="text-sm font-black text-white">درگاه مستقل اتریش‌نشین</h4>
                <p className="text-[9px] text-zinc-400 font-bold">بزرگترین کانون همیاری فارسی‌زبانان اتریش</p>
              </div>
            </div>

            <p className="text-[10px] text-zinc-300 leading-snug font-bold">
              «اتریش‌نشین» پورتالی داوطلبانه برای هم‌افزایی هموطنان و راهنمای دانشجویان و خانواده‌هاست. طراحی ابزارهای هوشمند، محاسبات Brutto-Netto، و تسهیل مسیرهای اداری را برای شما آسان کرده‌ایم. بدون وابستگی سیاسی.
            </p>

            <div className="bg-white/5 border border-white/5 p-2 rounded-xl flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400 shrink-0" />
              <p className="text-[9px] text-zinc-400 leading-snug font-bold">
                حامی مستقل و کاربردی شما در تمامی گام‌های زندگی.
              </p>
            </div>
          </div>

          {/* Column 2: Joining Networks (Contact Information) */}
          <div className="lg:col-span-5 space-y-2">
            <h5 className="text-[10px] font-black text-white uppercase tracking-wider flex items-center gap-1 justify-end">
              <span className="w-1 h-2 bg-blue-600 rounded-xs"></span>
              🔗 شبکه‌های ما:
            </h5>

            <div className="grid grid-cols-2 gap-2">
              <a 
                href="https://t.me/OTRISH_IRAN" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-between p-2 bg-sky-500/10 hover:bg-sky-500/15 border border-sky-500/20 rounded-lg transition-all font-black text-[9px] text-sky-300 hover:scale-102"
              >
                <Send className="w-3 h-3 text-sky-455 shrink-0" />
                <span className="font-mono">OTRISH_IRAN@</span>
              </a>

              <a 
                href="https://instagram.com/otrish__iran" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-between p-2 bg-pink-500/10 hover:bg-pink-500/15 border border-pink-500/20 rounded-lg transition-all font-black text-[9px] text-pink-300 hover:scale-102"
              >
                <Instagram className="w-3 h-3 text-pink-455 shrink-0" />
                <span className="font-mono">otrish__iran@</span>
              </a>

              <a 
                href="https://t.me/Otrish_neshin" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-between p-2 bg-indigo-550/10 hover:bg-indigo-550/15 border border-indigo-500/20 rounded-lg transition-all font-black text-[9px] text-indigo-300 hover:scale-102"
              >
                <ExternalLink className="w-3 h-3 text-indigo-400 shrink-0" />
                <span className="font-mono">Otrish_neshin@</span>
              </a>

              <a 
                href="https://www.facebook.com/otrish.neshin" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-between p-2 bg-blue-600/10 hover:bg-blue-600/15 border border-blue-500/20 rounded-lg transition-all font-black text-[9px] text-blue-300 hover:scale-102"
              >
                <Facebook className="w-3 h-3 text-blue-400 shrink-0" />
                <span className="font-mono">otrish.neshin@</span>
              </a>
            </div>

            <div className="bg-stone-900/50 border border-white/5 rounded-lg p-2 text-right space-y-1">
              <h6 className="text-[9px] font-black text-stone-300">📱 تماس واتس‌اپ:</h6>
              <div className="grid grid-cols-2 gap-1">
                <a 
                  href="https://wa.me/436889763256" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex flex-col items-center justify-center p-1 bg-emerald-500/10 hover:bg-emerald-500/15 border border-emerald-500/20 rounded-lg transition-all text-[8px] font-semibold font-mono text-emerald-300 hover:scale-102 text-center"
                >
                  <span className="font-sans text-[7px] text-stone-400 font-bold">اتریش</span>
                  <span>436889763256+</span>
                </a>

                <a 
                  href="https://wa.me/989306229790" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex flex-col items-center justify-center p-1 bg-emerald-500/10 hover:bg-emerald-500/15 border border-emerald-500/20 rounded-lg transition-all text-[8px] font-semibold font-mono text-emerald-300 hover:scale-102 text-center"
                >
                  <span className="font-sans text-[7px] text-stone-400 font-bold">ایران</span>
                  <span>989306229790+</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        {/* Flat Divider & Credits */}
        <div className="max-w-7xl mx-auto border-t border-zinc-900 mt-6 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10.5px] font-black text-stone-500">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="w-2 h-2 rounded-full bg-blue-600"></span>
            <span>طراحی گران‌سنگ اختصاصی برای کانون شریف ایرانیان مقیم اتریش © {new Date().getFullYear()}</span>
            <span className="text-blue-500 opacity-60">🇦🇹</span>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: 'اتریش‌نشین',
                    url: window.location.href,
                    text: 'همیار همه‌جانبه فارسی‌زبانان مقیم اتریش'
                  }).catch(console.error);
                } else {
                  navigator.clipboard.writeText(window.location.href);
                  toast.success("لینک سایت کپی شد!");
                }
              }}
              className="flex items-center gap-1.5 bg-red-100/50 hover:bg-red-200/50 text-red-700 px-3 py-1.5 rounded-full font-black text-[10px] transition-all"
            >
              <Share2 className="w-3 h-3" />
              اشتراک‌گذاری سایت
            </button>
          </div>
          <div className="font-mono text-[9px] text-stone-400">
            Otrish-Iran Community Portal (Otrishneshin Hub)
          </div>
        </div>
      </footer>

      {/* Global SuperApp Search Modal (Command Palette / Fuzzy Search) */}
      <SuperAppSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectPage={(segment) => {
          setActiveSegment(segment);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
      />

      {/* Modern Fixed Mobile Bottom Navigation Bar */}
      <SuperAppMobileBottomNav
        activeSegment={activeSegment}
        onSelectSegment={(segment) => {
          setActiveSegment(segment);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        onOpenSearch={() => setIsSearchModalOpen(true)}
        onOpenNews={() => setIsNewsModalOpen(true)}
        onOpenCategories={() => setIsMobileNavOpen(true)}
      />

      {/* Mobile & Tablet Hamburger Navigation Drawer */}
      <MobileNavigationDrawer
        activeSegment={activeSegment}
        setActiveSegment={(segment) => {
          setActiveSegment(segment);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        isOpen={isMobileNavOpen}
        onClose={() => setIsMobileNavOpen(false)}
      />

      <NewsModal
        isOpen={isNewsModalOpen}
        onClose={() => setIsNewsModalOpen(false)}
        news={austriaNews}
        newsSourceText={newsSourceText}
        newsLastUpdated={newsLastUpdated}
        isNewsLoading={isNewsLoading}
        isForcingNewsRefresh={isForcingNewsRefresh}
        onRefresh={() => fetchAustriaNewsList(true)}
      />

      <WhatsAppConsultButton />
      <ToastNotification />
    </div>
    </>
  );
}
